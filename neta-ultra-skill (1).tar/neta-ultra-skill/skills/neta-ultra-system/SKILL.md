---
name: neta-ultra-system
description: 捏Ta系统工具技能 — OSS文件上传、配置管理、AB实验、Agent机器人、MQTT实时推送、设备注册、等待列表、短链接、音频BGM、作品管理。
---

# 捏Ta系统工具 (neta-ultra-system)

系统级API — 文件上传、配置、实时通信、设备管理、工具函数。

## OSS 文件上传

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/oss/anonymous-upload-token` | 🔓 | 匿名上传STS Token (suffix参数) |
| `GET` | `/v1/oss/sts-upload-token` | 🔒 | 登录上传STS Token (suffix参数) |

> 返回STS临时凭证: access_key_id, access_key_secret, security_token

```bash
# 匿名上传
GET /v1/oss/anonymous-upload-token?suffix=png&t=1234567890

# 登录上传
GET /v1/oss/sts-upload-token?suffix=png&t=1234567890
```

## 作品管理 (Artifact)

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/artifact/list` | 🔒 | 作品列表 (分页, modality过滤, is_starred) |
| `GET` | `/v1/artifact/artifact-detail` | 🔒 | 作品详情 (uuids逗号分隔) |
| `GET` | `/v1/artifact/picture-detail` | 🔒 | 图片作品详情 |
| `GET` | `/v1/artifact/video-detail` | 🔒 | 视频作品详情 |
| `GET` | `/v1/artifact/video-stream-url` | 🔒 | 视频流URL |
| `GET` | `/v1/artifact/video-stream/{uuid}` | 🔒 | 视频流 |
| `GET` | `/v1/artifact/video_task/{uuid}` | 🔒 | 视频任务状态 |
| `GET` | `/v1/artifact/task/{taskId}` | 🔒 | 任务状态 |
| `GET` | `/v1/artifact/verse/list` | 🔒 | Verse作品列表 |
| `GET` | `/v1/artifact/verse/task` | 🔒 | Verse任务 |
| `GET` | `/v1/artifact/verse/checkpoint` | 🔒 | Verse检查点 |
| `GET` | `/v1/artifact/tcp-permissions-for-same-style` | 🔒 | 同款权限 |
| `POST` | `/v1/artifact/picture` | 🔒 | 创建图片作品 (url) |
| `POST` | `/v1/artifact/video` | 🔒 | 创建视频作品 (url) |
| `PUT` | `/v1/artifact/{uuid}` | 🔒 | 更新作品 |
| `DELETE` | `/v1/artifact` | 🔒 | 删除作品 (uuid) |
| `DELETE` | `/v1/verse/artifact/{uuid}` | 🔒 | 删除Verse作品 |
| `PATCH` | `/v1/artifact/verse` | 🔒 | 更新Verse作品 |
| `PUT` | `/v1/artifact/modify-audio-name` | 🔒 | 修改音频名称 |

## 配置系统

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/configs/config-list` | 🔓 | 配置列表 (namespace必填) |
| `GET` | `/v1/configs/config` | 🔓 | 单条配置 (namespace, name) |
| `POST` | `/v1/ab-experiment/get-or-join/all-running` | 🔓 | 加入AB实验 |
| `GET` | `/v1/app-release/latest-release` | 🔓 | 最新版本 (channel) |
| `GET` | `/v1/app/loads` | 🔒 | App加载资源 |

## Agent 聊天机器人

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/agent/limit-exceeded` | 🔒 | 额度检查 |
| `POST` | `/v1/agent/` | 🔒 | 创建Agent对话 |
| `DELETE` | `/v1/agent/{id}` | 🔒 | 删除Agent |

## MQTT 实时推送

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `POST` | `/v1/mqtt/client` | 🔒 | 获取MQTT连接凭证 (client_id) |

## 设备管理

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `POST` | `/v1/device/register` | 🔒 | 注册设备 (token, platform) |
| `POST` | `/v1/device/deregister` | 🔒 | 注销设备 |

## 等待列表

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/waitlist/status` | 🔓 | 查询状态 (feature_key: 目前仅html_patch) |
| `POST` | `/v1/waitlist/apply` | 🔒 | 申请加入 (feature_key, reason) |

## 工具函数

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `POST` | `/v1/util/short-url` | 🔓 | 生成短链接 (original_url) |
| `GET` | `/v1/util/original-url` | 🔓 | 解析短链接 (short_url) |
| `GET` | `/v1/util/get-readable` | 🔓 | 可读信息 |

## 音频/BGM

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/audio/bgm/list` | 🔓 | BGM列表 (分页) |
| `GET` | `/v1/audio/bgm` | 🔓 | BGM详情 (uuid) |

## 任务系统 (Assignment)

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/assignment/assignment-list` | 🔒 | 任务列表 (无参数) |
| `POST` | `/v1/assignment/user-assignment` | 🔒 | 获取/创建用户任务 (body: `{uuid: assignment_uuid}`) |
| `PUT` | `/v1/assignment/complete-assignment-action` | 🔒 | 完成任务 (body: `{uuid: user_assignment_uuid, assignment_action_type}`) |

## 使用示例

```typescript
const apis = createUltraApis();

// 获取上传Token
const stsToken = await apis.oss.anonymousUploadToken("png");
// 使用STS凭证上传到OSS...

// 获取作品列表
const artifacts = await apis.artifact.list({ page_index: 0, modality: "IMAGE" });

// 获取BGM列表
const bgmList = await apis.audio.bgmList();
console.log(bgmList.list.map(b => b.name));

// 注册推送设备
await apis.device.register({ token: "fcm_token", platform: "android" });

// 加入AB实验
await apis.config.joinExperiment();

// 获取MQTT凭证
const mqttConfig = await apis.mqtt.getClient("my-client-id");
```
