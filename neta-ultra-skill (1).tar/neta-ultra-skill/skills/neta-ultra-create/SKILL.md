---
name: neta-ultra-create
description: 捏Ta创作技能 — AI图片/视频/音乐/MV生成、Verse创作引擎、手稿系统、图片编辑、Prompt/RAG系统。
---

# 捏Ta创作 (neta-ultra-create)

全量创作API — 从素材生成到作品管理。

## V3 生成接口 (📱 需要x-platform头)

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `POST` | `/v3/make_image` | 🔒📱 | **生成图片** — rawPrompt必填 |
| `POST` | `/v3/make_video` | 🔒📱 | **生成视频** |
| `POST` | `/v3/make_song` | 🔒📱 | **生成音乐** |
| `POST` | `/v3/make_face_detailer` | 🔒📱 | 面部细化/后处理 |
| `POST` | `/v3/video_tool_adjust_speed` | 🔒📱 | 视频变速工具 |
| `POST` | `/v3/ai_director_merge_video_submit_task` | 🔒 | AI导演合并视频 |
| `POST` | `/v3/merge_media/v3/submit_task` | 🔒 | 合并媒体提交 |

### 任务状态查询

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v3/task?taskId={id}` | 🔒 | 任务状态查询 (返回task_status, artifacts等) |
| `GET` | `/v3/task-pool` | 🔒 | 任务池状态 |
| `GET` | `/v3/video_model_list` | 🔓 | 视频模型列表 |

### 生成任务轮询

```bash
# 1. 提交生成任务
POST /v3/make_image
Body: { "rawPrompt": "@character_name, description", "aspect": "3:4", ... }
Response: "task-uuid-string"

# 2. 轮询任务状态
GET /v3/task?taskId={task_uuid}
Response: { task_status: "PENDING" | "SUCCESS" | "FAILED", artifacts: [...] }
```

## Verse 创作引擎

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/verse/catalog` | 🔓 | Verse分类目录 |
| `GET` | `/v1/verse/catalog/{uuid}` | 🔓 | 分类详情 |
| `GET` | `/v1/verse/preset/{uuid}` | 🔓 | Verse模板/预设 |
| `GET` | `/v1/verse/tool` | 🔓 | Verse工具 |
| `POST` | `/v1/verse/background_start` | 🔒 | 启动后台运行 (artifact_load_uuid) |
| `POST` | `/v1/verse/background_stop` | 🔒 | 停止后台运行 |
| `GET` | `/v1/verse/background_is_running/{uuid}` | 🔒 | 后台状态查询 |
| `GET` | `/v1/verse/background_should_stop/{uuid}` | 🔒 | 后台结束信号 |
| `POST` | `/v1/verse/screenshot` | 🔒 | 截取Verse画面 |
| `POST` | `/v1/verse/modifyhtml` | 🔒 | 修改Verse HTML |

## 手稿系统 (Manuscript)

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/manuscript/list` | 🔒 | 手稿列表 |
| `GET` | `/v1/manuscript/{uuid}` | 🔒 | 手稿详情 |
| `POST` | `/v1/manuscript` | 🔒 | 创建手稿 |
| `PUT` | `/v1/manuscript/{uuid}` | 🔒 | 全量更新手稿 |
| `PATCH` | `/v1/manuscript/{uuid}` | 🔒 | 部分更新手稿 |
| `DELETE` | `/v1/manuscript/{uuid}` | 🔒 | 删除手稿 |

## 图片编辑

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `POST` | `/v1/image_edit_v1/task` | 🔒 | 提交图片编辑任务 |

## Prompt / RAG 系统

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/prompt/full-prompt-tags` | 🔒 | 提示词标签 |
| `GET` | `/v1/rag/cached-inspiration` | 🔒 | 缓存灵感数据 |
| `POST` | `/v1/rag/rag-recommend-stories` | 🔒 | RAG推荐故事 |

## GPT / Dify

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v3/gpt/message/{uuid}` | 🔒 | GPT消息 |
| `POST` | `/v3/gpt/dify/text-complete` | 🔒📱 | Dify流式文本补全 (需要Device-id) |

### Dify 流式调用示例

```bash
POST /v3/gpt/dify/text-complete
Headers: {
  "x-token": "...",
  "x-platform": "nieta-app/android",
  "Content-Type": "application/json",
  "Device-id": "your-device-uuid"
}
Body: {
  "query": "",
  "response_mode": "streaming",
  "preset_key": "AI帮写帖子",  // 或 "奇遇总结"
  "inputs": {
    "title": "...",
    "description": "...",
    "prompt": "..."
  }
}
```

## 使用示例

```typescript
const apis = createUltraApis();

// 生成图片
const taskUuid = await apis.make.makeImage({
  rawPrompt: "@character_name, beautiful sunset, 4k",
  // ...other params
});

// 轮询结果
const result = await apis.task.get(taskUuid);
if (result.task_status === "SUCCESS") {
  console.log("生成的图片:", result.artifacts);
}

// 获取BGM列表
const bgmList = await apis.audio.bgmList();
```
