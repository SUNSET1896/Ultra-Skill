---
name: neta-ultra-character
description: 捏Ta角色技能 — OC创建管理/TCP系统/旅行角色/养成(Parent)/活动(Campaign)/VToken/面具/角色聊天(C-Chat)。
---

# 捏Ta角色 (neta-ultra-character)

全量角色系统API — 原创角色(OC)、旅行养成、RPG活动。

## OC (Original Character) V2

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v2/oc/oc/{uuid}` | 🔒 | OC详情 |
| `GET` | `/v2/oc/list-worlds` | 📱 | 世界列表 (需要x-platform) |
| `GET` | `/v2/oc/tcp-hashtag-candidates` | 🔒 | Hashtag候选 |
| `GET` | `/v2/oc/tcp-expand` | 🔒 | TCP扩展 |
| `POST` | `/v2/oc/oc` | 🔒 | 创建OC |
| `POST` | `/v2/oc/make_oc_bio` | 🔒 | AI生成OC简介 |
| `PATCH` | `/v2/oc/oc/{uuid}` | 🔒 | 更新OC |
| `DELETE` | `/v2/oc/oc/{uuid}` | 🔒 | 删除OC |

## 旅行角色 (Travel Characters)

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/travel/characters/{uuid}` | 🔒 | 角色详情V1 |
| `GET` | `/v2/travel/characters` | 🔒📱 | 角色列表V2 (需要x-platform) |
| `GET` | `/v2/travel/characters/{uuid}` | 🔒📱 | 角色详情V2 |
| `POST` | `/v2/travel/characters` | 🔒📱 | 创建旅行角色 |

## 旅行任务 (Mission Records)

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/travel/mission-records/{uuid}` | 🔒 | 任务记录V1 |
| `GET` | `/v2/travel/mission-records/{uuid}` | 🔒 | 任务记录V2 |
| `GET` | `/v3/travel/mission-record/{uuid}` | 🔒 | 任务记录V3 |
| `PATCH` | `/v1/travel/mission-records/{uuid}` | 🔒 | 更新记录V1 |
| `PATCH` | `/v2/travel/mission-records/{uuid}` | 🔒 | 更新记录V2 |

## 养成系统 (Parent)

### 核心CRUD

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v2/travel/parent` | 🔒 | 养成列表 |
| `GET` | `/v2/travel/parent/{uuid}` | 🔒 | 养成详情 |
| `POST` | `/v2/travel/parent` | 🔒 | 创建养成 |
| `PATCH` | `/v2/travel/parent/{uuid}` | 🔒 | 更新养成 |
| `DELETE` | `/v2/travel/parent/{uuid}` | 🔒 | 删除养成 |

### 目录和搜索 (🔓 无需登录)

| 方法 | 路径 | 说明 |
|------|------|------|
| `GET` | `/v2/travel/parent-catalog` | 养成目录列表 |
| `GET` | `/v2/travel/parent-catalog/{uuid}` | 目录详情 |
| `GET` | `/v2/travel/parent-catalog/entries` | 目录条目 |
| `GET` | `/v2/travel/parent-search` | 养成搜索 |
| `GET` | `/v2/travel/parent-search-community` | 社区养成搜索 |
| `GET` | `/v2/travel/parent-search-under-hashtag` | Hashtag下搜索 |

### 收藏 (🔒)

| 方法 | 路径 | 说明 |
|------|------|------|
| `GET` | `/v2/travel/parent/bulk/list?in_editor={bool}` | 批量养成列表 |
| `PUT` | `/v2/travel/parent/parent-favor` | 收藏养成 |
| `GET` | `/v2/travel/parent/parent-favor/groups` | 收藏分组 |
| `GET` | `/v2/travel/parent/parent-favor/list` | 收藏列表 |

## 活动 (Campaign)

### 浏览 (🔓 无需登录)

| 方法 | 路径 | 说明 |
|------|------|------|
| `GET` | `/v2/travel/campaign-search` | 活动搜索 |
| `GET` | `/v2/travel/campaign/bulk/list` | 活动批量列表 |
| `GET` | `/v2/travel/campaign/catalog/{uuid}` | 活动目录 |
| `GET` | `/v2/travel/campaign/catalogs` | 活动目录列表 |

### 管理 (🔒)

| 方法 | 路径 | 说明 |
|------|------|------|
| `GET` | `/v3/travel/campaign/{uuid}` | 活动详情 |
| `GET` | `/v3/travel/campaign/recommend` | 活动推荐 |
| `GET` | `/v3/travel/campaigns` | 活动列表 |
| `DELETE` | `/v3/travel/campaign/{uuid}` | 删除活动 |

## 角色聊天 (C-Chat)

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/cchat/conversations/{uuid}` | 🔒 | 对话列表 |
| `GET` | `/v1/cchat/conversation/{uuid}` | 🔒 | 对话详情 |
| `POST` | `/v1/cchat/conversation/{uuid}` | 🔒 | 开始对话 |
| `POST` | `/v1/cchat/conversation/casual` | 🔒 | 闲聊模式 |
| `POST` | `/v1/cchat/conversation/primary` | 🔒 | 主要对话 |
| `POST` | `/v1/cchat/conversation/travel` | 🔒 | 旅行对话 |

## 记忆系统 (TC_MEM)

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/tc_mem/memory` | 🔒 | 记忆查询 (tcp_uuid) |
| `GET` | `/v1/tc_mem/reflection` | 🔒 | 反思记录 |
| `GET` | `/v1/tc_mem/experiences` | 🔒 | 经验列表 |
| `GET` | `/v1/tc_mem/cchat-messages` | 🔒 | 聊天消息记忆 |
| `POST` | `/v1/tc_mem/cchat-messages` | 🔒 | 创建聊天记忆 |
| `POST` | `/v1/tc_mem/experiences/abstracts/sample` | 🔒 | 经验抽样 |
| `DELETE` | `/v1/tc_mem/context-messages` | 🔒 | 删除上下文 (context_uuid) |

## 面具 (Thoumask)

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/thoumask/masks` | 🔒 | 面具列表 |

## 使用示例

```typescript
const apis = createUltraApis();

// 创建OC
const oc = await apis.character.createOc({ name: "My OC", ... });

// 浏览养成目录
const catalogs = await apis.character.parentCatalog();

// 创建养成
await apis.character.createParent({ name: "My Parent", ... });

// 开始角色聊天
await apis.cchat.casualConversation({ character_uuid: "xxx", message: "Hi!" });

// 查看记忆
const memories = await apis.memory.getMemory("tcp-uuid");
```
