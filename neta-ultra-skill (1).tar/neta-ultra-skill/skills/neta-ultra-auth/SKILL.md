---
name: neta-ultra-auth
description: 捏Ta认证技能 — 登录/注册/Token管理/匿名用户。覆盖手机验证码登录、微信/Apple/Google三方登录、一键登录、Token刷新、匿名用户创建。
---

# 捏Ta认证 (neta-ultra-auth)

管理捏Ta平台的用户认证全流程。

## API端点

### 手机验证码登录

**请求验证码** (🔓 无需登录)
```bash
POST /v1/user/request-verification-code
Body: { "phone_num": "13800138000" }
```

**验证码登录** (🔓)
```bash
POST /v1/user/verify-with-phone-num
Body: { "phone_num": "13800138000", "code": "123456" }
Response: { token, expires_in, refresh_token, refresh_expires_in, is_register, token_version }
```

### 第三方登录

**微信登录** (🔓)
```bash
POST /v1/user/verify-with-wechat-app-connect
Body: { "code": "wx_auth_code", "appid": "wx_app_id" }
```

**Apple登录** (🔓)
```bash
POST /v1/user/verify-with-apple
Body: {
  "auth": {
    "client_id": "art.nieta",
    "code": "apple_auth_code",
    "redirect_url_used": "https://..."
  }
}
```

**Google登录** (🔓)
```bash
POST /v1/user/verify-with-google
Body: { "auth": { "client_id": "...", "code": "..." } }
```

**一键登录** (🔓)
```bash
POST /v1/user/verify-one-login
Body: { /* one-login token payload */ }
```

### Token管理

**刷新Token** (🔒 使用大写X-Token)
```bash
PUT /v1/user/refresh-token
Headers: { "X-Token": "{current_token}", "Content-Type": "application/json" }
Body: {}
Response: { token, expires_in, refresh_token, refresh_expires_in, token_version }
```

**登出** (🔒)
```bash
POST /v1/user/logout
Body: {}
```

### 匿名用户

**创建匿名用户** (📱 需要x-platform)
```bash
POST /v2/users/anonymous
Body: { /* optional user data */ }
```

**创建广告优化匿名用户** (🔓 完全无需认证!)
```bash
POST /v2/users/anonymous-ad
Body: {}
Response: { uuid, nick_name, avatar_url }
```

## 使用示例

```typescript
import { createUltraApis } from "../src/apis/index.ts";

const apis = createUltraApis();

// 请求验证码
await apis.auth.requestVerificationCode("13800138000");

// 手机登录
const loginRes = await apis.auth.loginByPhone({
  phone_num: "13800138000",
  code: "123456",
});
console.log("Token:", loginRes.token);

// 刷新Token
const refreshed = await apis.auth.refreshToken();

// 创建匿名用户 (广告优化)
const anon = await apis.auth.createAnonymousAdUser();
console.log("Anonymous UUID:", anon.uuid);
```
