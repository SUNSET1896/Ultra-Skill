---
name: neta-ultra-community
description: 捏Ta社区技能 — 空间(Space)/动态(Moment)/标签(Hashtag)/世界观(Lore)/评论/点赞/订阅。覆盖全部社区互动API。
---

# 捏Ta社区 (neta-ultra-community)

全量社区功能API — 空间浏览、动态发布、标签管理、世界观系统。

## 空间 (Space)

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/space/get-by-hashtag?hashtag_name={name}` | 🔓 | 通过标签获取空间 |
| `GET` | `/v1/space/topics?space_uuid={uuid}` | 🔓 | 空间话题列表 |
| `GET` | `/v1/space/footprint?space_uuid={uuid}` | 🔓 | 空间足迹 |
| `GET` | `/v1/space/playground/list?space_uuid={uuid}` | 🔓 | 空间游乐场 |
| `GET` | `/v1/space/collection/feed` | 🔓 | 空间作品集 (page_index, space_uuid) |
| `POST` | `/v1/space/increase/footprint` | 🔒 | 增加足迹 (space_uuid) |
| `POST` | `/v1/space/remove` | 🔒 | 移除空间 |

## 动态 (Moment)

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/space/moment/detail?moment_uuid={uuid}` | 🔓 | 动态详情 |
| `POST` | `/v1/space/moment/publish` | 🔒 | 发布动态 |
| `POST` | `/v1/space/moment/like` | 🔒 | 点赞动态 |
| `POST` | `/v1/space/moment/comment` | 🔒 | 评论动态 |
| `POST` | `/v1/space/moment/delete` | 🔒 | 删除动态 |
| `DELETE` | `/v1/space/moment/comment/delete?uuid={uuid}` | 🔒 | 删除评论 |
| `POST` | `/v1/space/admin/moment/ban` | 🔒 | 禁言 |

## 标签 (Hashtag)

### 浏览 (全部🔓无需登录)

| 方法 | 路径 | 说明 |
|------|------|------|
| `GET` | `/v1/hashtag/community-top` | 热门社区标签 |
| `GET` | `/v1/hashtag/typeahead/{query}` | 标签搜索提示 |
| `GET` | `/v1/hashtag/typeahead-v2/{query}` | 标签搜索V2 |
| `GET` | `/v1/hashtag/hashtag_info/{name}` | 标签详情 |
| `GET` | `/v1/hashtag/hot-collections` | 热门合集 (hashtag_name必填) |
| `GET` | `/v1/hashtag/latest-hottest-collection` | 最新最热合集 |
| `GET` | `/v1/hashtag/subscribe-count` | 订阅计数 |
| `GET` | `/v1/hashtag/tcp-count` | TCP计数 |
| `GET` | `/v1/hashtag/feed_hashtags` | Feed标签 |
| `GET` | `/v1/hashtag/lores-count` | Lore计数 |

### 操作 (全部🔒需要登录)

| 方法 | 路径 | 说明 |
|------|------|------|
| `POST` | `/v1/hashtag/` | 创建Hashtag |
| `POST` | `/v1/hashtag/subscribe` | 订阅/取消 (hashtag_name, behavior) |
| `POST` | `/v1/hashtag/subscribe-bulk` | 批量订阅 |
| `POST` | `/v1/hashtag/modify` | 修改标签 |
| `POST` | `/v1/hashtag/remove-top/{name}` | 取消置顶 |

## 世界观 (Lore)

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `POST` | `/v1/hashtag/lore` | 🔒 | 获取/创建Lore |
| `POST` | `/v1/hashtag/lore/modify` | 🔒 | 修改Lore |
| `POST` | `/v1/hashtag/lore/delete` | 🔒 | 删除Lore |
| `POST` | `/v1/hashtag/lore/events` | 🔒 | Lore事件 |
| `POST` | `/v1/hashtag/lore/event/sort-index-bulk` | 🔒 | 批量排序Lore事件 |

## 故事互动

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `PUT` | `/v1/story/story-like` | 🔒 | 点赞/取消点赞 (story_id, behavior) |
| `PUT` | `/v1/story/story-favor` | 🔒 | 收藏/取消收藏 |
| `PUT` | `/v1/story/story-publish?storyId={id}` | 🔒 | 发布故事 |
| `PUT` | `/v2/story/story` | 🔒 | 发布故事V2 |
| `POST` | `/v3/story/pin` | 🔒 | 置顶故事 |
| `DELETE` | `/v3/story/collection` | 🔒 | 删除合集 (uuids) |

## 合集互动

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/collection-interactive/search` | 🔒 | 搜索互动合集 |
| `GET` | `/v1/collection-interactive/char_roll?num={n}` | 🔒 | 角色轮转 |
| `GET` | `/v1/collection-interactive/collection_uuid={uuid}` | 🔒 | 合集详情 |
| `PUT` | `/v1/collection-interactive` | 🔒 | 创建/更新互动 |
| `PUT` | `/v1/collection-interactive/text_reply` | 🔒 | 文本回复 |
| `PUT` | `/v1/collection-interactives/video-input` | 🔒 | 视频输入 |
| `PUT` | `/v1/collection-interactives/vtokens` | 🔒 | VToken操作 |

## 审核

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `POST` | `/v1/moderate/appeal` | 🔒 | 申诉 (user_uuid, target_uuid, target_type, content) |

## 使用示例

```typescript
const apis = createUltraApis();

// 浏览热门标签
const hotTags = await apis.hashtag.communityTop();

// 搜索标签
const results = await apis.hashtag.typeaheadV2("捏捏");

// 获取标签信息
const info = await apis.hashtag.getInfo("捏捏");

// 订阅标签
await apis.hashtag.subscribe("捏捏", "subscribe");

// 发布动态
await apis.community.publishMoment({ content: "...", space_uuid: "..." });

// 点赞故事
await apis.community.likeStory({ story_id: "xxx", behavior: "like" });
```
