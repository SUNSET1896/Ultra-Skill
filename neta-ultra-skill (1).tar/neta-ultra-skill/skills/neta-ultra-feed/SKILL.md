---
name: neta-ultra-feed
description: 捏Ta Feed流技能 — 首页推荐/互动Feed/动态Feed/状态队列/合集浏览/草稿管理。
---

# 捏Ta Feed流 (neta-ultra-feed)

浏览和管理捏Ta首页的推荐内容流。

## API端点

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/home/feed/mainlist` | 🔓 | **首页Feed主列表** — 返回热门/最新/关注等tab内容 |
| `GET` | `/v1/home/feed/interactive` | 🔓 | **互动Feed** — 互动合集推荐 |
| `GET` | `/v1/home/feed/dynamic` | 🔓 | **动态Feed** — 关注用户的动态流 |
| `GET` | `/v1/home/status_queue` | 🔒 | 首页状态队列 |
| `GET` | `/v1/home/draft` | 🔒 | 首页草稿 |
| `GET` | `/v1/home/collection/{uuid}` | 🔒 | 首页合集详情 |
| `PUT` | `/v1/home/feature/record` | 🔒 | 记录首页浏览特征 |

### Feed主列表参数

```
GET /v1/home/feed/mainlist?theme=热门&page_index=0&page_size=10
```

可选theme值: `最新`, `关注`, `热门`, `⚔️捏捏开荒团`, `🍭社团活动`, `#游戏`, `#番剧`, `#oc`, `#漫画`, `#V圈`, `#小说`, `#影视`

### 响应结构

```typescript
{
  module_list_header: { module_list: [...] },  // 顶部筛选器
  module_list: [
    {
      data_id: "uuid",
      module_id: "normal_unit",
      template_id: "NORMAL",
      json_data: {
        id: number, name: string, coverUrl: string,
        likeCount: number, sameStyleCount: number,
        is_interactive: boolean, has_video: boolean,
        view_scheme: "/collection/interaction?uuid=...",
        user_nick_name: string, user_avatar_url: string,
        // ...
      }
    },
    {
      template_id: "ACTIVITY",  // 活动卡片
      // ...
    }
  ],
  page_data: { has_next_page: boolean, page_index: number }
}
```

### 故事浏览

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v2/story/bulk-list` | 🔓 | 批量故事列表 |
| `GET` | `/v2/story/user-stories` | 🔒 | 用户故事列表 |
| `GET` | `/v2/story/liked-list` | 🔒 | 点赞故事列表 |
| `GET` | `/v2/story/liked-list-cursor` | 🔒 | 点赞列表(游标分页) |
| `GET` | `/v2/story/favor-list-cursor` | 🔒 | 收藏列表(游标分页) |
| `GET` | `/v2/story/newbie/tcp-feed` | 🔒 | 新手推荐Feed |
| `GET` | `/v3/story/story-detail` | 🔒 | V3故事详情 (uuids逗号分隔) |
| `GET` | `/v3/story/feeds` | 🔒 | V3故事Feed |
| `GET` | `/v3/story/same-style-stories` | 🔒 | V3同款故事 |
| `GET` | `/v3/story/collection-pin-status/{uuid}` | 🔒 | 置顶状态查询 |
| `GET` | `/v3/story/travel` | 🔒 | 旅行故事 |

## 使用示例

```typescript
const apis = createUltraApis();

// 获取首页Feed
const feed = await apis.feeds.getMainList({ theme: "热门" });
console.log(`获取到 ${feed.module_list.length} 个模块`);

// 获取互动Feed
const interactive = await apis.feeds.getInteractiveFeed({ page_index: 1 });
```
