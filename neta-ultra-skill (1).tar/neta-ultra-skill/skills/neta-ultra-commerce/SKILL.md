---
name: neta-ultra-commerce
description: 捏Ta电商技能 — 商品浏览/订单管理/AP购买/邀请码/签到/消息通知/特权管理/VIP。
---

# 捏Ta电商与增值 (neta-ultra-commerce)

商城购物、电量管理、签到奖励、消息通知、VIP特权。

## 商品系统

### 浏览 (🔓 无需登录)

| 方法 | 路径 | 说明 |
|------|------|------|
| `GET` | `/v1/commerce/spu-list` | 商品列表 |
| `GET` | `/v1/commerce/spu-detail/{uuid}` | 商品详情 |

商品类型:
- 电量包 (AP): `[首充福利] 200电量`, `300电量`, `980电量`, `1980电量`, `6480电量`
- VIP会员: 月卡/季卡/年卡

### 购买 (🔒)

| 方法 | 路径 | 说明 |
|------|------|------|
| `GET` | `/v1/commerce/user-items` | 我的物品/背包 |
| `PATCH` | `/v1/commerce/user-items/{uuid}` | 使用物品 |
| `GET` | `/v1/commerce/orders` | 订单列表 |
| `GET` | `/v1/commerce/orders/{uuid}` | 订单详情 |
| `POST` | `/v1/commerce/orders` | 创建订单 |
| `POST` | `/v1/commerce/orders/{uuid}` | 创建订单(带ID) |
| `POST` | `/v1/commerce/purchase_spu_by_ap/{uuid}` | **AP直接购买商品** |
| `GET` | `/v1/commerce/gift_list` | 礼物列表 |

### 邀请码

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `POST` | `/v1/coupon/create` | 🔒 | 创建邀请码 (返回coupon_code) |
| `POST` | `/v1/coupon/redeem` | 🔒 | 兑换邀请码 (coupon_code) |

## 每日签到

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/checkin/status` | 🔒 | 签到状态 (today_signed, streak_count, rewards) |
| `POST` | `/v1/checkin/manual` | 🔒 | 执行签到 (Body: {}) |

签到奖励节奏: Day1: 100AP → Day2: 100AP → Day3: 200AP → Day4: ...

## 消息通知

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/message/message-list` | 🔒 | 消息列表 (分页) |
| `GET` | `/v1/message/message-count` | 🔒 | 未读消息数 (按section分组) |
| `PUT` | `/v1/message/message` | 🔒 | 标记已读 (msg_uuid) |

消息类型 (section_enum):
- `SEC_PUBLIC` — 公告
- `SEC_LIKE` — 点赞
- `SEC_SUBSCRIBE` — 关注
- `SEC_INTERACTS` — 互动

## 特权管理

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/privilege/config/water_mark_remove` | 🔒 | 去水印状态 |
| `POST` | `/v1/privilege/config/water_mark_remove?enable={0\|1}` | 🔒 | 开关去水印 |

## 活动列表

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/activities` | 🔓 | 活动列表 |
| `GET` | `/v1/activities/{uuid}` | 🔓 | 活动详情 |

## 使用示例

```typescript
const apis = createUltraApis();

// 浏览商品
const spuList = await apis.commerce.spuList();
console.log(spuList.list.map(s => `${s.name}: ¥${s.price}`));

// 签到
const status = await apis.checkin.status();
if (!status.today_signed) {
  await apis.checkin.manual();
}

// 查看未读消息
const msgCount = await apis.message.count();
console.log(msgCount.data);

// 创建邀请码
const coupon = await apis.commerce.createCoupon();
console.log("邀请码:", coupon.coupon_code);
```
