---
name: neta-ultra
description: 捏Ta Ultra Skill — 全量API索引与路由技能。覆盖 app.nieta.art 全部30+模块、170+API端点。当你需要了解捏Ta完整能力、选择合适子技能或执行API操作时使用此技能。
---

# 捏Ta Ultra Skill (Neta-Ultra)

捏Ta (app.nieta.art) 全量API逆向工程的总索引和路由技能。

> 本技能是捏Ta全量API的"目录"和"入口"。根据具体任务类型，选择对应的子技能执行。所有子技能共享同一套API客户端和认证体系。

## 快速开始

```bash
# 安装
git clone https://github.com/talesofai/neta-ultra-skill.git
cd neta-ultra-skill
pnpm install

# 设置Token
export NETA_TOKEN="your_jwt_token_here"

# 使用
npx tsx src/cli.ts
```

## 子技能索引

| 技能 | 用途 | 文件 |
|------|------|------|
| `neta-ultra-auth` | 认证: 登录/注册/Token/匿名用户 | [SKILL.md](./neta-ultra-auth/SKILL.md) |
| `neta-ultra-user` | 用户: 资料/AP电量/关注/拉黑/徽章 | [SKILL.md](./neta-ultra-user/SKILL.md) |
| `neta-ultra-feed` | Feed流: 首页推荐/互动/动态/合集浏览 | [SKILL.md](./neta-ultra-feed/SKILL.md) |
| `neta-ultra-create` | 创作: 图片/视频/音乐/Verse/手稿 | [SKILL.md](./neta-ultra-create/SKILL.md) |
| `neta-ultra-community` | 社区: 空间/动态/标签/世界观/评论/点赞 | [SKILL.md](./neta-ultra-community/SKILL.md) |
| `neta-ultra-character` | 角色: OC/TCP/旅行/养成/活动 | [SKILL.md](./neta-ultra-character/SKILL.md) |
| `neta-ultra-commerce` | 电商: 商品/订单/电量购买/邀请码/签到 | [SKILL.md](./neta-ultra-commerce/SKILL.md) |
| `neta-ultra-system` | 系统: OSS/配置/Agent/记忆/MQTT/设备/审核等 | [SKILL.md](./neta-ultra-system/SKILL.md) |

## 认证体系

### 国内版 (api.talesofai.cn)

请求头 `x-token` (大小写均可):

```bash
curl -H "x-token: $NETA_TOKEN" https://api.talesofai.cn/v1/user/
```

### 海外版 (api.talesofai.com)

OIDC设备登录流程 (Bearer Token):

```bash
# 获取device code
curl -X POST https://auth.neta.art/oidc/device/auth -d "client_id=...&scope=..."

# 轮询token
curl -X POST https://auth.neta.art/oidc/token -d "client_id=...&grant_type=urn:ietf:params:oauth:grant-type:device_code&device_code=..."
```

### 通用请求头

| Header | 值 | 说明 |
|--------|-----|------|
| `x-token` / `X-Token` | JWT | 认证令牌 |
| `x-platform` | `nieta-app/android` / `nieta-app/android` / `nieta-app/ios` | 平台标识(部分API必须) |
| `x-nieta-app-version` | `6.11.5` | App版本 |
| `x-teen-mode` | `0` / `1` | 青少年模式 |
| `Device-id` | UUID | Dify流式接口需要 |

## 权限模型

- 🔓 公开 (无需登录): ~45个接口 — Feed浏览、标签查询、BGM列表、商品浏览等
- 🔒 需登录: ~120个接口 — 所有写操作、生成、用户私有数据
- 📱 需x-platform头: ~15个接口 — make_image/video/song、travel characters等

## 环境变量

```
NETA_TOKEN=           # JWT Token (直接认证)
NETA_API_BASE_URL=    # API基地址 (默认 https://api.talesofai.cn)
NETA_AUTH_API_BASE_URL= # OIDC服务 (海外版, 默认 https://auth.neta.art)
NETA_CLIENT_ID=       # OIDC Client ID
```

## 参考

- 原始逆向分析: [API_ANALYSIS.md](../../API_ANALYSIS.md)
- API源码: [src/apis/](../../src/apis/)
- 类型定义: [src/apis/types.ts](../../src/apis/types.ts)
