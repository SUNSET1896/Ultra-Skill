---
name: neta-ultra-user
description: 捏Ta用户技能 — 个人资料获取/更新、AP(电量)查询、关注/拉黑管理、徽章/头像框、IM权限检查。
---

# 捏Ta用户 (neta-ultra-user)

管理用户资料、社交关系和徽章系统。

## API端点

### 用户信息

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/user/` | 🔒 | 获取当前用户完整信息 |
| `GET` | `/v1/user/?uuid={uuid}` | 🔓 | 查询用户公开信息 |
| `PUT` | `/v1/user/user` | 🔒 | 更新资料 (nick_name, avatar_url) |

### AP(电量)系统

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v2/user/ap_info` | 🔒 | 当前AP信息 (ap, ap_limit, unlimited_until) |
| `GET` | `/v2/users/ap-delta-info` | 🔒 | AP消耗历史 (cursor_id, page_size) |

### 社交关系

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `PUT` | `/v1/user/user-subscribe` | 🔒 | 关注/取消关注 (user_uuid, is_cancel) |
| `PUT` | `/v1/user/user-blacklist` | 🔒 | 拉黑/取消拉黑 (user_uuid, is_cancel) |
| `GET` | `/v1/user/subscribe-list` | 🔒 | 关注列表 |
| `GET` | `/v1/user/fan-list` | 🔒 | 粉丝列表 |
| `GET` | `/v1/user/check_im` | 🔒 | IM权限检查 (receiver, only_check) |

### 徽章系统

| 方法 | 路径 | 权限 | 说明 |
|------|------|------|------|
| `GET` | `/v1/badge/me/badges` | 🔒 | 我的全部徽章 |
| `PUT` | `/v1/badge/me/active-avatar-frame` | 🔒 | 设置活跃头像框 (badge_uuid) |

### 用户信息字段说明

```typescript
interface UserInfo {
  id: number;           // 用户ID
  uuid: string;         // 用户UUID
  nick_name: string;    // 昵称
  avatar_url: string;   // 头像
  status: "VERIFIED" | "UNVERIFIED" | "DELETE";
  ap_info: {
    ap: number;         // 当前电量
    ap_limit: number;   // 电量上限
    unlimited_until: number | null;  // 无限时长
  };
  total_subscribes: number;  // 关注数
  total_fans: number;        // 粉丝数
  total_likes: string;       // 获赞数
  total_same_style: string;  // 被捏同款数
  total_collections: string; // 作品数
  is_anonymous: boolean;     // 是否匿名
  is_wechat_verified: boolean; // 绑定微信
  is_apple_verified: boolean;  // 绑定Apple
  badges: Badge[];           // 徽章列表
  privileges: UserPrivilege[]; // 权益列表
}
```

## 使用示例

```typescript
const apis = createUltraApis();

// 获取我的信息
const me = await apis.user.me();
console.log(`电量: ${me.ap_info?.ap}/${me.ap_info?.ap_limit}`);

// 查询其他用户
const other = await apis.user.getUser("some-user-uuid");

// 关注用户
await apis.user.subscribeUser({ user_uuid: "target-uuid" });

// 获取徽章
const badges = await apis.user.getMyBadges();
```
