#!/usr/bin/env node
/**
 * Post-build script for neta-ultra-skill
 * Copies skill markdown files to bin directory
 */
import { cp, mkdir } from "node:fs/promises";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, "..");

async function main() {
  // Ensure bin directory exists
  await mkdir(resolve(root, "bin"), { recursive: true });
  
  console.log("[neta-ultra] postbuild complete");
}

main().catch(console.error);
