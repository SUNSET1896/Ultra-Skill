# Neta-Ultra-Skill

> 🚀 **捏Ta (app.nieta.art) 全量API逆向工程 Skill**
>
> 覆盖 **30+模块、170+API端点**，从 app.nieta.art v6.11.5 JS源码逆向还原。

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Node](https://img.shields.io/badge/node-%3E%3D22.0.0-brightgreen)](package.json)

---

## 📦 安装

```bash
git clone https://github.com/talesofai/neta-ultra-skill.git
cd neta-ultra-skill
pnpm install
```

## 🔑 配置

```bash
# 设置API Token (JWT)
export NETA_TOKEN="eyJhbGciOiJIUzI1NiIs..."

# API地址 (默认国内)
export NETA_API_BASE_URL="https://api.talesofai.cn"
```

## 🎯 技能清单

| Skill | 用途 | API数量 |
|-------|------|---------|
| **[neta-ultra-auth](./skills/neta-ultra-auth/SKILL.md)** | 认证: 登录/注册/Token/匿名用户 | 10+ |
| **[neta-ultra-user](./skills/neta-ultra-user/SKILL.md)** | 用户: 资料/AP/关注/拉黑/徽章 | 12+ |
| **[neta-ultra-feed](./skills/neta-ultra-feed/SKILL.md)** | Feed流: 首页推荐/互动/故事浏览 | 20+ |
| **[neta-ultra-create](./skills/neta-ultra-create/SKILL.md)** | 创作: 图片/视频/音乐/Verse/手稿 | 25+ |
| **[neta-ultra-community](./skills/neta-ultra-community/SKILL.md)** | 社区: 空间/动态/标签/世界观/Lore | 40+ |
| **[neta-ultra-character](./skills/neta-ultra-character/SKILL.md)** | 角色: OC/TCP/旅行/养成/活动/C-Chat | 45+ |
| **[neta-ultra-commerce](./skills/neta-ultra-commerce/SKILL.md)** | 电商: 商品/订单/签到/消息/特权 | 25+ |
| **[neta-ultra-system](./skills/neta-ultra-system/SKILL.md)** | 系统: OSS/配置/Agent/MQTT/设备等 | 30+ |

## 🏗️ 项目结构

```
neta-ultra-skill/
├── skills/                    # Skill文档 (SKILL.md)
│   ├── neta-ultra/            # 总索引
│   ├── neta-ultra-auth/       # 认证
│   ├── neta-ultra-user/       # 用户
│   ├── neta-ultra-feed/       # Feed流
│   ├── neta-ultra-create/     # 创作
│   ├── neta-ultra-community/  # 社区
│   ├── neta-ultra-character/  # 角色
│   ├── neta-ultra-commerce/   # 电商
│   └── neta-ultra-system/     # 系统工具
├── src/
│   ├── apis/                  # API客户端模块
│   │   ├── index.ts           # 总入口 (createUltraApis)
│   │   ├── auth.ts            # 认证API
│   │   ├── user.ts            # 用户API
│   │   ├── feeds.ts           # Feed流API
│   │   ├── artifact.ts        # 作品API
│   │   ├── create.ts          # 创作API (Verse/GPT/生成)
│   │   ├── community.ts       # 社区API
│   │   ├── hashtag.ts         # 标签API
│   │   ├── character.ts       # 角色API
│   │   ├── commerce.ts        # 电商/消息/签到API
│   │   ├── system.ts          # 系统工具API
│   │   ├── misc.ts            # 手稿/编辑/面具等
│   │   └── types.ts           # 类型定义
│   ├── cli.ts                 # CLI入口
│   └── utils/                 # 工具函数
├── API_ANALYSIS.md            # 完整逆向分析报告
└── README.zh_cn.md            # 中文文档
```

## 🚀 快速使用

### TypeScript/Node.js

```typescript
import { createUltraApis } from "neta-ultra-skill";

const apis = createUltraApis();

// 获取用户信息
const me = await apis.user.me();
console.log(`用户: ${me.nick_name}, 电量: ${me.ap_info?.ap}`);

// 获取首页Feed
const feed = await apis.feeds.getMainList({ theme: "热门" });

// 浏览热门标签
const hotTags = await apis.hashtag.communityTop();

// 签到
const checkin = await apis.checkin.manual();
```

### cURL 直接调用

```bash
# 获取用户信息 (需要登录)
curl -s "https://api.talesofai.cn/v1/user/" -H "x-token: $NETA_TOKEN"

# 首页Feed (无需登录)
curl -s "https://api.talesofai.cn/v1/home/feed/mainlist"

# 热门标签 (无需登录)
curl -s "https://api.talesofai.cn/v1/hashtag/community-top"

# 签到 (需要登录)
curl -s -X POST "https://api.talesofai.cn/v1/checkin/manual" \
  -H "x-token: $NETA_TOKEN" -H "Content-Type: application/json" -d '{}'
```

## 📡 认证体系

| 方式 | 适用 | 请求头 |
|------|------|--------|
| JWT直接 | 国内 `api.talesofai.cn` | `x-token: {jwt}` |
| OIDC Bearer | 海外 `api.talesofai.com` | `Authorization: Bearer {token}` |

## 📖 完整逆向分析

详见 [API_ANALYSIS.md](./API_ANALYSIS.md) — 包含全部170+端点的参数、返回值、权限分类。

## 📄 License

MIT
