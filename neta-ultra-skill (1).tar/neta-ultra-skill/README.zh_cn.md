# Neta-Ultra-Skill 中文文档

> 🚀 **捏Ta (app.nieta.art) 全量API逆向工程 Skill**
>
> 覆盖 **30+模块、170+API端点**，从 app.nieta.art v6.11.5 JS源码逆向还原。

## 项目背景

本项目对捏Ta (app.nieta.art) 进行了完整的JS逆向分析，逐一解析了所有前端Bundle文件中的API调用逻辑、请求头构造方式、认证机制，最终还原出全部API端点及其使用方法。

### 逆向分析范围

- **入口HTML**: `app.nieta.art` 主页面
- **JS Bundle文件**: 12个核心Bundle (index, framework, common, core, components, mqtt, router, generate, litellm, solid, hls, gsap)
- **API发现**: 从JS源码提取 `.get()`, `.post()`, `.put()`, `.patch()`, `.delete()` 调用
- **认证还原**: `constructHeaders()` 函数完整还原
- **Token流程**: JWT解析、刷新机制完整还原
- **实时验证**: 对数百个端点进行了实际的HTTP请求验证

## 技能说明

| Skill | 用途 | 语言 |
|-------|------|------|
| [neta-ultra](./skills/neta-ultra/SKILL.md) | 总索引与路由 | 中文 |
| [neta-ultra-auth](./skills/neta-ultra-auth/SKILL.md) | 认证: 登录/注册/Token | 中文 |
| [neta-ultra-user](./skills/neta-ultra-user/SKILL.md) | 用户: 资料/AP/社交 | 中文 |
| [neta-ultra-feed](./skills/neta-ultra-feed/SKILL.md) | Feed流 | 中文 |
| [neta-ultra-create](./skills/neta-ultra-create/SKILL.md) | 创作: AI生成 | 中文 |
| [neta-ultra-community](./skills/neta-ultra-community/SKILL.md) | 社区互动 | 中文 |
| [neta-ultra-character](./skills/neta-ultra-character/SKILL.md) | 角色系统 | 中文 |
| [neta-ultra-commerce](./skills/neta-ultra-commerce/SKILL.md) | 电商增值 | 中文 |
| [neta-ultra-system](./skills/neta-ultra-system/SKILL.md) | 系统工具 | 中文 |

## API 权限模型

| 标识 | 含义 | 数量 | 典型接口 |
|------|------|------|----------|
| 🔓 | **无需登录** | ~45个 | Feed浏览、标签查询、BGM、商品浏览、匿名用户创建 |
| 🔒 | **需要登录** | ~120个 | 所有写操作、AI生成、用户数据、签到、点赞 |
| 📱 | **需要x-platform头** | ~15个 | make_image、make_video、travel characters |

## 请求头规范

```typescript
// 完整请求头模板
{
  "x-token": "eyJ...",                          // JWT Token (有token时必备)
  "x-platform": "nieta-app/android",                // 平台 (部分API必须)
  "x-nieta-app-version": "6.11.5",              // App版本
  "x-teen-mode": "0",                           // 青少年模式
  "Device-id": "uuid",                          // Dify流式接口需要
  "Content-Type": "application/json"            // JSON请求体
}
```

### constructHeaders() 函数还原

```javascript
// 从 talesofai-modules-core-cSUdSjKQ.js 逆向还原
async function constructHeaders() {
  const baseHeaders = {
    "x-platform": isAndroid ? "nieta-app/android" 
      : isIOS ? "nieta-app/ios" 
      : "nieta-app/web",
    "x-nieta-app-version": appVersion,
    "x-teen-mode": isTeenMode ? "1" : "0"
  };
  
  const token = accessToken.snapshot;
  if (token) {
    baseHeaders["x-token"] = token;
  }
  
  return { ...baseHeaders, ...customHeaders };
}
```

## API端点总览

### 认证模块 (10个端点)
- 手机/微信/Apple/Google登录
- Token刷新/登出
- 匿名用户创建

### 用户模块 (12个端点)
- 个人信息CRUD、AP管理、关注/拉黑、徽章

### Feed模块 (20个端点)
- 首页推荐、互动Feed、故事浏览

### 创作模块 (25个端点)
- AI图片/视频/音乐生成、Verse引擎、Prompt系统

### 社区模块 (40个端点)
- 空间/动态/标签/世界观/Lore/合集互动

### 角色模块 (45个端点)
- OC/TCP/旅行/养成/活动/C-Chat/记忆系统

### 电商模块 (25个端点)
- 商品/订单/AP购买/签到/消息/特权

### 系统模块 (30个端点)
- OSS上传/配置/Agent/MQTT/设备/工具

## 完整分析报告

详见 [API_ANALYSIS.md](./API_ANALYSIS.md) — 包含全部170+端点的详细参数说明、返回值格式、权限分类及实际调用示例。

该报告是逆向分析的完整产物，记录了:
- 每个API的HTTP方法和路径
- 是否需要认证
- 关键请求参数
- 响应格式
- 实际测试验证结果

## License

MIT
