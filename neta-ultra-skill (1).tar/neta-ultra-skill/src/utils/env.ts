import dotenv from "dotenv-flow";
dotenv.config({ silent: true });

export const IS_DEV = process.env["NODE_ENV"] === "development";

/** API基地址: 国内 talesofai.cn / 海外 talesofai.com */
export const API_BASE_URL =
  process.env["NETA_API_BASE_URL"] ?? "https://api.talesofai.cn";

/** OIDC认证地址 */
export const AUTH_API_BASE_URL =
  process.env["NETA_AUTH_API_BASE_URL"] ?? "https://auth.neta.art";

/** OIDC客户端ID */
export const CLIENT_ID =
  process.env["NETA_CLIENT_ID"] ?? "ft6zb5zp7fqmq8y807okv";

/** JWT Token (直接方式认证, 国内版推荐) */
export const NETA_TOKEN = process.env["NETA_TOKEN"] ?? "";

/** 是否全球版 */
export const IS_GLOBAL = API_BASE_URL.endsWith("talesofai.com");

/** App版本号 (用于x-nieta-app-version头) */
export const APP_VERSION = "6.11.5";

/** App Bundle版本 (Android特有) */
export const APP_BUNDLE_VERSION = "6.11.5";

/** App Bundle版本号 (Android特有) */
export const APP_BUNDLE_VERSION_CODE = "6110500";

/** 平台标识 — 模拟安卓App端 */
export const PLATFORM = "nieta-app/android";
