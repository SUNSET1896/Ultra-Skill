export class ApiResponseError extends Error {
  code: number;
  data: unknown;

  constructor(code: number, message: string, data?: unknown) {
    super(message);
    this.name = "ApiResponseError";
    this.code = code;
    this.data = data;
  }

  static fromAxios(error: { response?: { status?: number; data?: unknown }; message?: string }) {
    const status = error.response?.status ?? -1;
    const data = error.response?.data;
    const msg = typeof data === "object" && data !== null && "detail" in data
      ? String((data as Record<string, unknown>).detail)
      : (error.message ?? "Unknown error");
    return new ApiResponseError(status, msg, data);
  }
}

export const errors = {
  need_login: "用户未登录，请设置 NETA_TOKEN 环境变量",
  token_expired: "Token已过期，请刷新或重新设置",
  network_error: "网络连接失败",
  not_found: "请求的资源不存在",
  forbidden: "权限不足",
  app_only: "此接口仅接受App请求，请添加 x-platform 头",
} as const;

export const handleAxiosError = (error: unknown): never => {
  throw ApiResponseError.fromAxios(error as Parameters<typeof ApiResponseError.fromAxios>[0]);
};

export const safeParseJson = (raw: string): unknown => {
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
};
