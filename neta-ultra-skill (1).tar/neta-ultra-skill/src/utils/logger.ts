export const logger = {
  debug: (...args: unknown[]) => console.debug("[neta-ultra]", ...args),
  info: (...args: unknown[]) => console.info("[neta-ultra]", ...args),
  warn: (...args: unknown[]) => console.warn("[neta-ultra]", ...args),
  error: (...args: unknown[]) => console.error("[neta-ultra]", ...args),
};
