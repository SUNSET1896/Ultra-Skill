import { deleteConfig, readConfig, writeConfig } from "./config.ts";
import { NETA_TOKEN } from "./env.ts";

const TOKEN_KEY = "token";
const TOKEN_REFRESH_ENDPOINT = "/v1/user/refresh-token";

export interface TokenStore {
  token: string;
  expiresAt: number;
  refreshToken: string;
  refreshExpiresAt: number;
  version: number;
  isRegister?: boolean;
}

export const storeToken = async (t: TokenStore): Promise<boolean> => {
  return writeConfig(TOKEN_KEY, JSON.stringify(t));
};

export const readToken = async (): Promise<TokenStore | null> => {
  const raw = await readConfig(TOKEN_KEY);
  if (!raw) {
    // fallback: use env token
    if (NETA_TOKEN) {
      return {
        token: NETA_TOKEN,
        expiresAt: 0,
        refreshToken: "",
        refreshExpiresAt: 0,
        version: 0,
      };
    }
    return null;
  }
  try {
    return JSON.parse(raw) as TokenStore;
  } catch {
    return null;
  }
};

export const deleteToken = async (): Promise<boolean> => {
  return deleteConfig(TOKEN_KEY);
};

export const isTokenExpired = (t: TokenStore): boolean => {
  if (t.expiresAt <= 0) return false; // env token, unknown expiry
  return t.expiresAt * 1000 < Date.now();
};

/** 检查token有效性的简单JWT解码 */
export const decodeJwtPayload = (token: string) => {
  try {
    const payload = token.split(".")[1];
    if (!payload) return null;
    return JSON.parse(Buffer.from(payload, "base64").toString("utf-8"));
  } catch {
    return null;
  }
};

export { TOKEN_REFRESH_ENDPOINT };
