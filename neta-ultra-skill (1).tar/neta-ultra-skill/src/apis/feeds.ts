/**
 * Neta-Ultra API — Feed流模块
 * 首页内容推荐/浏览
 */
import type { AxiosInstance } from "axios";
import type { FeedListResponse } from "./types.ts";

export const createFeedsApis = (client: AxiosInstance) => {
  return {
    /** 首页Feed主列表 (无需登录) */
    getMainList: (params?: { page_index?: number; page_size?: number; theme?: string }) =>
      client.get<FeedListResponse>("/v1/home/feed/mainlist", { params }).then(r => r.data),

    /** 互动Feed (无需登录) */
    getInteractiveFeed: (params?: { page_index?: number; page_size?: number }) =>
      client.get("/v1/home/feed/interactive", { params }).then(r => r.data),

    /** 动态Feed (关注流) */
    getDynamicFeed: (params?: { page_index?: number; page_size?: number }) =>
      client.get("/v1/home/feed/dynamic", { params }).then(r => r.data),

    /** 状态队列 */
    getStatusQueue: () => client.get("/v1/home/status_queue").then(r => r.data),

    /** 首页合集详情 */
    getHomeCollection: (uuid: string) =>
      client.get(`/v1/home/collection/${uuid}`).then(r => r.data),

    /** 首页草稿 */
    getDraft: (params?: Record<string, unknown>) =>
      client.get("/v1/home/draft", { params }).then(r => r.data),

    /** 记录首页特征 */
    recordFeature: (data: Record<string, unknown>) =>
      client.put("/v1/home/feature/record", data).then(r => r.data),
  };
};
