/**
 * Neta-Ultra API — 角色/OC/TCP模块
 */
import type { AxiosInstance } from "axios";

export const createCharacterApis = (client: AxiosInstance) => {
  // ====== OC (Original Character) V2 ======
  return {
    /** OC详情 */
    getOc: (uuid: string) =>
      client.get(`/v2/oc/oc/${uuid}`).then(r => r.data),

    /** 世界列表 (需要x-platform头) */
    listWorlds: () =>
      client.get("/v2/oc/list-worlds").then(r => r.data),

    /** Hashtag候选 */
    tcpHashtagCandidates: (params?: Record<string, unknown>) =>
      client.get("/v2/oc/tcp-hashtag-candidates", { params }).then(r => r.data),

    /** TCP扩展 */
    tcpExpand: (params?: Record<string, unknown>) =>
      client.get("/v2/oc/tcp-expand", { params }).then(r => r.data),

    /** 创建OC */
    createOc: (data: Record<string, unknown>) =>
      client.post("/v2/oc/oc", data).then(r => r.data),

    /** 生成OC简介 */
    makeOcBio: (data: Record<string, unknown>) =>
      client.post("/v2/oc/make_oc_bio", data).then(r => r.data),

    /** 更新OC */
    updateOc: (uuid: string, data: Record<string, unknown>) =>
      client.patch(`/v2/oc/oc/${uuid}`, data).then(r => r.data),

    /** 删除OC */
    deleteOc: (uuid: string) =>
      client.delete(`/v2/oc/oc/${uuid}`).then(r => r.data),

    // ====== 旅行角色 (Travel Character) ======
    /** 角色列表V1 */
    getTravelCharacterV1: (uuid: string) =>
      client.get(`/v1/travel/characters/${uuid}`).then(r => r.data),

    /** 角色列表V2 (需要x-platform) */
    getTravelCharactersV2: () =>
      client.get("/v2/travel/characters").then(r => r.data),

    /** 角色详情V2 */
    getTravelCharacterV2: (uuid: string) =>
      client.get(`/v2/travel/characters/${uuid}`).then(r => r.data),

    /** 创建角色V2 */
    createTravelCharacter: (data: Record<string, unknown>) =>
      client.post("/v2/travel/characters", data).then(r => r.data),

    // ====== 养成 (Parent) ======
    /** 养成列表 */
    getParent: (params?: Record<string, unknown>) =>
      client.get("/v2/travel/parent", { params }).then(r => r.data),

    /** 养成详情 */
    getParentDetail: (uuid: string) =>
      client.get(`/v2/travel/parent/${uuid}`).then(r => r.data),

    /** 创建养成 */
    createParent: (data: Record<string, unknown>) =>
      client.post("/v2/travel/parent", data).then(r => r.data),

    /** 更新养成 */
    updateParent: (uuid: string, data: Record<string, unknown>) =>
      client.patch(`/v2/travel/parent/${uuid}`, data).then(r => r.data),

    /** 删除养成 */
    deleteParent: (uuid: string) =>
      client.delete(`/v2/travel/parent/${uuid}`).then(r => r.data),

    /** 养成目录 */
    parentCatalog: () =>
      client.get("/v2/travel/parent-catalog").then(r => r.data),

    /** 养成目录详情 */
    parentCatalogDetail: (uuid: string) =>
      client.get(`/v2/travel/parent-catalog/${uuid}`).then(r => r.data),

    /** 养成目录条目 */
    parentCatalogEntries: (params?: Record<string, unknown>) =>
      client.get("/v2/travel/parent-catalog/entries", { params }).then(r => r.data),

    /** 养成搜索 */
    parentSearch: (params?: Record<string, unknown>) =>
      client.get("/v2/travel/parent-search", { params }).then(r => r.data),

    /** 社区养成搜索 */
    parentSearchCommunity: (params?: Record<string, unknown>) =>
      client.get("/v2/travel/parent-search-community", { params }).then(r => r.data),

    /** Hashtag下养成搜索 */
    parentSearchUnderHashtag: (params?: Record<string, unknown>) =>
      client.get("/v2/travel/parent-search-under-hashtag", { params }).then(r => r.data),

    /** 批量养成列表 */
    parentBulkList: (in_editor = false) =>
      client.get(`/v2/travel/parent/bulk/list?in_editor=${in_editor}`).then(r => r.data),

    /** 收藏养成 */
    favorParent: (data: Record<string, unknown>) =>
      client.put("/v2/travel/parent/parent-favor", data).then(r => r.data),

    /** 收藏分组 */
    parentFavorGroups: () =>
      client.get("/v2/travel/parent/parent-favor/groups").then(r => r.data),

    /** 收藏列表 */
    parentFavorList: (params?: Record<string, unknown>) =>
      client.get("/v2/travel/parent/parent-favor/list", { params }).then(r => r.data),

    // ====== 活动 (Campaign) ======
    /** 活动搜索 */
    campaignSearch: (params?: Record<string, unknown>) =>
      client.get("/v2/travel/campaign-search", { params }).then(r => r.data),

    /** 活动批量列表 */
    campaignBulkList: (params?: Record<string, unknown>) =>
      client.get("/v2/travel/campaign/bulk/list", { params }).then(r => r.data),

    /** 活动目录详情 */
    campaignCatalog: (uuid: string) =>
      client.get(`/v2/travel/campaign/catalog/${uuid}`).then(r => r.data),

    /** 活动目录列表 */
    campaignCatalogs: () =>
      client.get("/v2/travel/campaign/catalogs").then(r => r.data),

    /** 活动详情V3 */
    getCampaignV3: (uuid: string) =>
      client.get(`/v3/travel/campaign/${uuid}`).then(r => r.data),

    /** 活动推荐 */
    campaignRecommend: () =>
      client.get("/v3/travel/campaign/recommend").then(r => r.data),

    /** 活动列表 */
    campaigns: () =>
      client.get("/v3/travel/campaigns").then(r => r.data),

    /** 删除活动 */
    deleteCampaign: (uuid: string) =>
      client.delete(`/v3/travel/campaign/${uuid}`).then(r => r.data),
  };
};
