/**
 * Neta-Ultra API — 合集互动、Verse、GPT、生成任务
 */
import type { AxiosInstance, AxiosRequestConfig } from "axios";

export const createCollectionApis = (client: AxiosInstance) => {
  return {
    /** 搜索互动合集 */
    search: (params?: Record<string, unknown>) =>
      client.get("/v1/collection-interactive/search", { params }).then(r => r.data),

    /** 角色轮转 */
    charRoll: (num = 10) =>
      client.get(`/v1/collection-interactive/char_roll?num=${num}`).then(r => r.data),

    /** 互动合集详情 */
    getByUuid: (collection_uuid: string) =>
      client.get(`/v1/collection-interactive/collection_uuid=${collection_uuid}`).then(r => r.data),

    /** 创建/更新互动 */
    update: (data: Record<string, unknown>) =>
      client.put("/v1/collection-interactive", data).then(r => r.data),

    /** 文本回复 */
    textReply: (data: Record<string, unknown>) =>
      client.put("/v1/collection-interactive/text_reply", data).then(r => r.data),

    /** 视频输入 */
    videoInput: (data: Record<string, unknown>) =>
      client.put("/v1/collection-interactives/video-input", data).then(r => r.data),

    /** VToken操作 */
    vtokens: (data: Record<string, unknown>) =>
      client.put("/v1/collection-interactives/vtokens", data).then(r => r.data),
  };
};

export const createVerseApis = (client: AxiosInstance) => {
  return {
    /** Verse分类目录 */
    catalog: () => client.get("/v1/verse/catalog").then(r => r.data),

    /** 分类详情 */
    catalogDetail: (uuid: string) =>
      client.get(`/v1/verse/catalog/${uuid}`).then(r => r.data),

    /** Verse预设/模板 */
    preset: (uuid: string) =>
      client.get(`/v1/verse/preset/${uuid}`).then(r => r.data),

    /** Verse工具 */
    tool: () => client.get("/v1/verse/tool").then(r => r.data),

    /** 后台运行状态查询 */
    isBackgroundRunning: (uuid: string) =>
      client.get(`/v1/verse/background_is_running/${uuid}`).then(r => r.data),

    /** 后台应停止 */
    shouldBackgroundStop: (uuid: string) =>
      client.get(`/v1/verse/background_should_stop/${uuid}`).then(r => r.data),

    /** 启动后台任务 */
    startBackground: (data: { artifact_load_uuid: string }) =>
      client.post("/v1/verse/background_start", data).then(r => r.data),

    /** 停止后台任务 */
    stopBackground: (data: { artifact_load_uuid: string }) =>
      client.post("/v1/verse/background_stop", data).then(r => r.data),

    /** 截图 */
    screenshot: (data: { context: Record<string, unknown> }) =>
      client.post("/v1/verse/screenshot", data).then(r => r.data),

    /** 修改HTML */
    modifyHtml: (data: Record<string, unknown>) =>
      client.post("/v1/verse/modifyhtml", data).then(r => r.data),
  };
};

export const createGptApis = (client: AxiosInstance) => {
  return {
    /** GPT消息 */
    getMessage: (uuid: string) =>
      client.get(`/v3/gpt/message/${uuid}`).then(r => r.data),

    /** Dify流式文本补全 (需要Device-id头) */
    difyTextComplete: (
      data: {
        query: string;
        response_mode?: string;
        preset_key: string;
        inputs: Record<string, unknown>;
      },
      config?: AxiosRequestConfig,
    ) =>
      client.post("/v3/gpt/dify/text-complete", {
        ...data,
        response_mode: data.response_mode ?? "streaming",
      }, config).then(r => r.data),
  };
};

export const createTaskApis = (client: AxiosInstance) => {
  return {
    /** 任务状态查询 */
    get: (taskId: string) =>
      client.get(`/v3/task?taskId=${taskId}`).then(r => r.data),

    /** 任务池状态 */
    pool: () => client.get("/v3/task-pool").then(r => r.data),

    /** 视频模型列表 */
    videoModelList: () => client.get("/v3/video_model_list").then(r => r.data),
  };
};

/** 生成图片 (V3) */
export const createMakeApis = (client: AxiosInstance) => {
  return {
    makeImage: (data: Record<string, unknown>, config?: AxiosRequestConfig) =>
      client.post<string>("/v3/make_image", data, config).then(r => r.data),

    makeVideo: (data: Record<string, unknown>, config?: AxiosRequestConfig) =>
      client.post<string>("/v3/make_video", data, config).then(r => r.data),

    makeSong: (data: Record<string, unknown>, config?: AxiosRequestConfig) =>
      client.post<string>("/v3/make_song", data, config).then(r => r.data),

    makeFaceDetailer: (data: Record<string, unknown>, config?: AxiosRequestConfig) =>
      client.post<string>("/v3/make_face_detailer", data, config).then(r => r.data),

    videoAdjustSpeed: (data: Record<string, unknown>, config?: AxiosRequestConfig) =>
      client.post("/v3/video_tool_adjust_speed", data, config).then(r => r.data),

    aiDirectorMergeVideo: (data: Record<string, unknown>) =>
      client.post("/v3/ai_director_merge_video_submit_task", data).then(r => r.data),

    mergeMedia: (data: Record<string, unknown>) =>
      client.post("/v3/merge_media/v3/submit_task", data).then(r => r.data),
  };
};
