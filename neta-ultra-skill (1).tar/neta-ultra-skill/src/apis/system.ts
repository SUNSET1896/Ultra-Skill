/**
 * Neta-Ultra API — 系统工具模块
 * OSS/配置/Agent/记忆/MQTT/审核/设备/等待列表等
 */
import type { AxiosInstance } from "axios";
import type { OssStsToken, MqttClientConfig } from "./types.ts";

export const createOssApis = (client: AxiosInstance) => {
  return {
    /** 匿名上传STS Token (无需登录) */
    anonymousUploadToken: (suffix: string) =>
      client.get<OssStsToken>("/v1/oss/anonymous-upload-token", {
        params: { suffix, t: Date.now() },
      }).then(r => r.data),

    /** 登录上传STS Token (需要登录) */
    stsUploadToken: (suffix: string) =>
      client.get<OssStsToken>("/v1/oss/sts-upload-token", {
        params: { suffix, t: Date.now() },
      }).then(r => r.data),
  };
};

export const createConfigApis = (client: AxiosInstance) => {
  return {
    /** 配置列表 */
    list: (namespace: string) =>
      client.get("/v1/configs/config-list", { params: { namespace } }).then(r => r.data),

    /** 单条配置 */
    get: (namespace: string, name: string) =>
      client.get("/v1/configs/config", { params: { namespace, name } }).then(r => r.data),

    /** 加入AB实验 */
    joinExperiment: (data?: Record<string, unknown>) =>
      client.post("/v1/ab-experiment/get-or-join/all-running", data ?? {}).then(r => r.data),

    /** 检查最新版本 */
    latestRelease: (channel = "official") =>
      client.get("/v1/app-release/latest-release", { params: { channel } }).then(r => r.data),

    /** App加载资源 */
    appLoads: () => client.get("/v1/app/loads").then(r => r.data),
  };
};

export const createAgentApis = (client: AxiosInstance) => {
  return {
    /** 额度检查 */
    limitExceeded: () =>
      client.get("/v1/agent/limit-exceeded").then(r => r.data),

    /** 创建Agent对话 */
    create: (data: Record<string, unknown>) =>
      client.post("/v1/agent/", data).then(r => r.data),

    /** 删除Agent */
    delete: (id: string) =>
      client.delete(`/v1/agent/${id}`).then(r => r.data),
  };
};

export const createMemoryApis = (client: AxiosInstance) => {
  return {
    /** 记忆查询 */
    getMemory: (tcp_uuid: string) =>
      client.get("/v1/tc_mem/memory", { params: { tcp_uuid } }).then(r => r.data),

    /** 反思 */
    getReflection: (params?: Record<string, unknown>) =>
      client.get("/v1/tc_mem/reflection", { params }).then(r => r.data),

    /** 经验 */
    getExperiences: (params?: Record<string, unknown>) =>
      client.get("/v1/tc_mem/experiences", { params }).then(r => r.data),

    /** 聊天消息 */
    getCchatMessages: (params?: Record<string, unknown>) =>
      client.get("/v1/tc_mem/cchat-messages", { params }).then(r => r.data),

    /** 创建聊天消息 */
    createCchatMessage: (data: Record<string, unknown>) =>
      client.post("/v1/tc_mem/cchat-messages", data).then(r => r.data),

    /** 经验抽样 */
    sampleExperiences: (data: Record<string, unknown>) =>
      client.post("/v1/tc_mem/experiences/abstracts/sample", data).then(r => r.data),

    /** 删除上下文消息 */
    deleteContextMessages: (context_uuid: string) =>
      client.delete("/v1/tc_mem/context-messages", { params: { context_uuid } }).then(r => r.data),
  };
};

export const createMqttApis = (client: AxiosInstance) => {
  return {
    /** 获取MQTT连接凭证 */
    getClient: (client_id?: string) =>
      client.post("/v1/mqtt/client", { client_id }).then(r => r.data),
  };
};

export const createModerateApis = (client: AxiosInstance) => {
  return {
    /** 申诉 */
    appeal: (data: {
      user_uuid: string;
      target_uuid: string;
      target_type: string;
      content: string;
    }) => client.post("/v1/moderate/appeal", data).then(r => r.data),
  };
};

export const createDeviceApis = (client: AxiosInstance) => {
  return {
    /** 注册设备(推送) */
    register: (data: { token: string; platform: string }) =>
      client.post("/v1/device/register", data).then(r => r.data),

    /** 注销设备 */
    deregister: (data: Record<string, unknown>) =>
      client.post("/v1/device/deregister", data).then(r => r.data),
  };
};

export const createWaitlistApis = (client: AxiosInstance) => {
  return {
    /** Waitlist状态 (feature_key目前仅支持 html_patch) */
    status: (feature_key: string) =>
      client.get("/v1/waitlist/status", { params: { feature_key } }).then(r => r.data),

    /** 申请Waitlist */
    apply: (feature_key: string, reason: string) =>
      client.post("/v1/waitlist/apply", { feature_key, reason }).then(r => r.data),
  };
};

export const createUtilApis = (client: AxiosInstance) => {
  return {
    /** 生成短链接 */
    shortUrl: (original_url: string) =>
      client.post("/v1/util/short-url", { original_url }).then(r => r.data),

    /** 解析短链接 */
    originalUrl: (short_url: string) =>
      client.get("/v1/util/original-url", { params: { short_url } }).then(r => r.data),

    /** 可读信息 */
    getReadable: (params?: Record<string, unknown>) =>
      client.get("/v1/util/get-readable", { params }).then(r => r.data),
  };
};

export const createCchatApis = (client: AxiosInstance) => {
  return {
    /** 对话列表 */
    getConversations: (uuid: string) =>
      client.get(`/v1/cchat/conversations/${uuid}`).then(r => r.data),

    /** 对话详情 */
    getConversation: (uuid: string) =>
      client.get(`/v1/cchat/conversation/${uuid}`).then(r => r.data),

    /** 创建对话 */
    createConversation: (uuid: string, data?: Record<string, unknown>) =>
      client.post(`/v1/cchat/conversation/${uuid}`, data ?? {}).then(r => r.data),

    /** 闲聊对话 */
    casualConversation: (data: Record<string, unknown>) =>
      client.post("/v1/cchat/conversation/casual", data).then(r => r.data),

    /** 主要对话 */
    primaryConversation: (data: Record<string, unknown>) =>
      client.post("/v1/cchat/conversation/primary", data).then(r => r.data),

    /** 旅行对话 */
    travelConversation: (data: Record<string, unknown>) =>
      client.post("/v1/cchat/conversation/travel", data).then(r => r.data),
  };
};

export const createPromptApis = (client: AxiosInstance) => {
  return {
    /** 提示词标签 */
    fullPromptTags: (params?: Record<string, unknown>) =>
      client.get("/v1/prompt/full-prompt-tags", { params }).then(r => r.data),

    /** 缓存灵感 */
    cachedInspiration: (params?: Record<string, unknown>) =>
      client.get("/v1/rag/cached-inspiration", { params }).then(r => r.data),

    /** RAG推荐故事 */
    ragRecommendStories: (data: Record<string, unknown>) =>
      client.post("/v1/rag/rag-recommend-stories", data).then(r => r.data),
  };
};

export const createStoryApis = (client: AxiosInstance) => {
  return {
    /** 新故事 */
    newStory: (params?: Record<string, unknown>) =>
      client.get("/v1/story/new-story", { params }).then(r => r.data),

    /** 故事详情V3 */
    detailV3: (uuids: string) =>
      client.get("/v3/story/story-detail", { params: { uuids } }).then(r => r.data),

    /** 故事Feed V3 */
    feedsV3: (params?: Record<string, unknown>) =>
      client.get("/v3/story/feeds", { params }).then(r => r.data),

    /** 同款故事 */
    sameStyleStories: (params?: Record<string, unknown>) =>
      client.get("/v3/story/same-style-stories", { params }).then(r => r.data),

    /** 同款权限V3 */
    tcpPermissionsForSameStyleV3: (params?: Record<string, unknown>) =>
      client.get("/v3/story/tcp-permissions-for-same-style", { params }).then(r => r.data),

    /** 置顶状态 */
    pinStatus: (uuid: string) =>
      client.get(`/v3/story/collection-pin-status/${uuid}`).then(r => r.data),

    /** 生成故事标题 */
    generateTitle: (data: Record<string, unknown>) =>
      client.post("/v3/story/generate-story-title", data).then(r => r.data),

    /** 置顶故事 */
    pin: (data: Record<string, unknown>) =>
      client.post("/v3/story/pin", data).then(r => r.data),

    /** 批量故事列表V2 */
    bulkListV2: (params?: Record<string, unknown>) =>
      client.get("/v2/story/bulk-list", { params }).then(r => r.data),

    /** 用户故事 */
    userStories: (params?: Record<string, unknown>) =>
      client.get("/v2/story/user-stories", { params }).then(r => r.data),

    /** 点赞列表 */
    likedList: (params?: Record<string, unknown>) =>
      client.get("/v2/story/liked-list", { params }).then(r => r.data),

    /** 点赞列表(游标) */
    likedListCursor: (params?: Record<string, unknown>) =>
      client.get("/v2/story/liked-list-cursor", { params }).then(r => r.data),

    /** 收藏列表(游标) */
    favorListCursor: (params?: Record<string, unknown>) =>
      client.get("/v2/story/favor-list-cursor", { params }).then(r => r.data),

    /** 新手Feed */
    newbieFeed: (params?: Record<string, unknown>) =>
      client.get("/v2/story/newbie/tcp-feed", { params }).then(r => r.data),

    /** 删除合集 */
    deleteCollection: (uuids: string[]) =>
      client.delete("/v3/story/collection", { params: { uuids: uuids.join(",") } }).then(r => r.data),
  };
};

export const createAudioApis = (client: AxiosInstance) => {
  return {
    /** BGM列表 */
    bgmList: (params?: { page_index?: number; page_size?: number }) =>
      client.get("/v1/audio/bgm/list", { params }).then(r => r.data),

    /** BGM详情 */
    bgm: (uuid: string) =>
      client.get("/v1/audio/bgm", { params: { uuid } }).then(r => r.data),
  };
};
