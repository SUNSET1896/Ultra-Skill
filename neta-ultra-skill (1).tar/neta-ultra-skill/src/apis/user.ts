/**
 * Neta-Ultra API — 用户模块
 */
import type { AxiosInstance } from "axios";
import type {
  UserInfo, UserApInfo, ApDeltaRecord, Badge,
} from "./types.ts";

export const createUserApis = (client: AxiosInstance) => {
  return {
    /** 获取当前用户完整信息 (需要登录) */
    me: () => client.get<UserInfo>("/v1/user/").then(r => r.data),

    /** 查询指定用户公开信息 (无需登录) */
    getUser: (uuid: string) =>
      client.get<UserInfo>(`/v1/user/?uuid=${uuid}`).then(r => r.data),

    /** 更新个人资料 */
    updateProfile: (data: {
      user_uuid: string;
      nick_name?: string;
      avatar_url?: string;
    }) => client.put("/v1/user/user", data).then(r => r.data),

    /** 获取AP(电量)信息 */
    apInfo: () => client.get<UserApInfo>("/v2/user/ap_info").then(r => r.data),

    /** AP消耗历史 */
    apHistory: (params?: { cursor_id?: number; page_size?: number }) =>
      client.get<{ items: ApDeltaRecord[]; has_next: boolean; next_cursor: number | null }>(
        "/v2/users/ap-delta-info", { params }
      ).then(r => r.data),

    /** 关注用户 */
    subscribeUser: (params: { user_uuid: string; is_cancel?: boolean }) =>
      client.put("/v1/user/user-subscribe", {
        user_uuid: params.user_uuid,
        is_cancel: params.is_cancel ?? false,
      }).then(r => r.data),

    /** 拉黑/取消拉黑 */
    blockUser: (params: { user_uuid: string; is_cancel?: boolean }) =>
      client.put("/v1/user/user-blacklist", {
        user_uuid: params.user_uuid,
        is_cancel: params.is_cancel ?? false,
      }).then(r => r.data),

    /** 获取关注列表 */
    getSubscribeList: (params?: { page_index?: number; page_size?: number }) =>
      client.get("/v1/user/subscribe-list", { params }).then(r => r.data),

    /** 获取粉丝列表 */
    getFanList: (params?: { page_index?: number; page_size?: number }) =>
      client.get("/v1/user/fan-list", { params }).then(r => r.data),

    /** 检查IM权限 */
    checkIM: (receiver: string, onlyCheck = false) =>
      client.get(`/v1/user/check_im?receiver=${receiver}&only_check=${onlyCheck ? 1 : 0}`)
        .then(r => r.data),

    /** 获取我的徽章 */
    getMyBadges: () => client.get<Badge[]>("/v1/badge/me/badges").then(r => r.data),

    /** 设置活跃头像框 */
    setAvatarFrame: (badge_uuid: string) =>
      client.put("/v1/badge/me/active-avatar-frame", { badge_uuid }).then(r => r.data),
  };
};
