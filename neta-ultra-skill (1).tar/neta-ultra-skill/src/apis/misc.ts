/**
 * Neta-Ultra API — 手稿/图片编辑/面具/特权/任务 等
 */
import type { AxiosInstance } from "axios";
import type { ManuscriptItem, Assignment } from "./types.ts";

export const createManuscriptApis = (client: AxiosInstance) => {
  return {
    list: (params?: { page_index?: number; page_size?: number }) =>
      client.get("/v1/manuscript/list", { params }).then(r => r.data),

    get: (uuid: string) =>
      client.get(`/v1/manuscript/${uuid}`).then(r => r.data),

    create: (data: Record<string, unknown>) =>
      client.post("/v1/manuscript", data).then(r => r.data),

    update: (uuid: string, data: Record<string, unknown>) =>
      client.put(`/v1/manuscript/${uuid}`, data).then(r => r.data),

    patch: (uuid: string, data: Record<string, unknown>) =>
      client.patch(`/v1/manuscript/${uuid}`, data).then(r => r.data),

    delete: (uuid: string) =>
      client.delete(`/v1/manuscript/${uuid}`).then(r => r.data),
  };
};

export const createImageEditApis = (client: AxiosInstance) => {
  return {
    /** 图片编辑任务 */
    createTask: (data: Record<string, unknown>) =>
      client.post("/v1/image_edit_v1/task", data).then(r => r.data),
  };
};

export const createThoumaskApis = (client: AxiosInstance) => {
  return {
    /** 面具列表 */
    getMasks: (params?: Record<string, unknown>) =>
      client.get("/v1/thoumask/masks", { params }).then(r => r.data),
  };
};

export const createPrivilegeApis = (client: AxiosInstance) => {
  return {
    /** 去水印状态 */
    getWatermarkState: () =>
      client.get("/v1/privilege/config/water_mark_remove").then(r => r.data),

    /** 设置去水印 */
    setWatermarkState: (enable: boolean) =>
      client.post(`/v1/privilege/config/water_mark_remove?enable=${enable ? 1 : 0}`, {}).then(r => r.data),
  };
};

export interface AssignmentItem {
  uuid: string;                    // user_assignment_uuid
  assignment_uuid: string;         // 任务模板uuid
  assignment_action_type: string;  // PUBLISH_COLLECTION | LIKE_COLLECTION | JOIN_GROUP | REWARDED_VIDEO_AD | CREATE_NIENIE
  type: "everyday" | "special";
  user_uuid: string;
  user_name: string;
  name: string;                    // 任务名称
  count: number;                   // 当前进度
  required_times: number;          // 需要次数
  reward: string;                  // 奖励描述 如 "电量+50"
  reward_color: string;
  reward_icon: string;
  status: "FINISHED" | "UNFINISHED";
  extra: Record<string, unknown>;
}

export const createAssignmentApis = (client: AxiosInstance) => {
  return {
    /** 获取任务列表 */
    list: () =>
      client.get<AssignmentItem[]>("/v1/assignment/assignment-list").then(r => r.data),

    /** 获取/创建用户任务 (body: {uuid: assignment_uuid}) */
    userAssignment: (assignment_uuid: string) =>
      client.post<AssignmentItem>("/v1/assignment/user-assignment", { uuid: assignment_uuid }).then(r => r.data),

    /** 完成任务 (body: {uuid: user_assignment_uuid, ...}) */
    complete: (user_assignment_uuid: string, action_type: string) =>
      client.put<AssignmentItem>("/v1/assignment/complete-assignment-action", {
        uuid: user_assignment_uuid,
        assignment_action_type: action_type,
      }).then(r => r.data),
  };
};

export const createMissionApis = (client: AxiosInstance) => {
  return {
    /** 任务记录V1 */
    getRecordsV1: (uuid: string) =>
      client.get(`/v1/travel/mission-records/${uuid}`).then(r => r.data),

    /** 任务记录V2 */
    getRecordsV2: (uuid: string) =>
      client.get(`/v2/travel/mission-records/${uuid}`).then(r => r.data),

    /** 更新任务记录V1 */
    updateRecordV1: (uuid: string, data: Record<string, unknown>) =>
      client.patch(`/v1/travel/mission-records/${uuid}`, data).then(r => r.data),

    /** 更新任务记录V2 */
    updateRecordV2: (uuid: string, data: Record<string, unknown>) =>
      client.patch(`/v2/travel/mission-records/${uuid}`, data).then(r => r.data),

    /** 任务记录V3 */
    getRecordV3: (uuid: string) =>
      client.get(`/v3/travel/mission-record/${uuid}`).then(r => r.data),

    /** 旅行故事 */
    storyTravel: () => client.get("/v3/story/travel").then(r => r.data),
  };
};

export const createActivityApis = (client: AxiosInstance) => {
  return {
    /** 活动列表 */
    list: () => client.get("/v1/activities").then(r => r.data),

    /** 活动详情 */
    detail: (uuid: string) => client.get(`/v1/activities/${uuid}`).then(r => r.data),
  };
};

export const createVerseArtifactApis = (client: AxiosInstance) => {
  return {
    /** 更新Verse作品 */
    patch: (data: Record<string, unknown>) =>
      client.patch("/v1/artifact/verse", data).then(r => r.data),

    /** 修改音频名称 */
    modifyAudioName: (data: Record<string, unknown>) =>
      client.put("/v1/artifact/modify-audio-name", data).then(r => r.data),
  };
};
