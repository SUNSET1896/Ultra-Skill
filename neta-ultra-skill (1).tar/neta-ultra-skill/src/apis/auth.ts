/**
 * Neta-Ultra API — 认证模块
 * 登录/注册/Token管理
 */
import type { AxiosInstance, AxiosRequestConfig } from "axios";

export interface LoginByPhoneRequest {
  phone_num: string;
  code: string;
}

export interface LoginByWechatRequest {
  code: string;
  appid: string;
}

export interface LoginByAppleRequest {
  code: string;
  client_id?: string;
  redirect_url_used?: string;
}

export interface LoginByGoogleRequest {
  code: string;
  client_id: string;
}

export interface LoginResponse {
  token: string;
  expires_in: number;
  refresh_token: string;
  refresh_expires_in: number;
  is_register: boolean;
  token_version: number;
}

export const createAuthApis = (client: AxiosInstance) => {
  return {
    /** 请求手机验证码 */
    requestVerificationCode: (phone_num: string, config?: AxiosRequestConfig) =>
      client.post("/v1/user/request-verification-code", { phone_num }, config).then(r => r.data),

    /** 手机号+验证码登录 */
    loginByPhone: (req: LoginByPhoneRequest, config?: AxiosRequestConfig) =>
      client.post<LoginResponse>("/v1/user/verify-with-phone-num", req, config).then(r => r.data),

    /** 微信登录 */
    loginByWechat: (req: LoginByWechatRequest, config?: AxiosRequestConfig) =>
      client.post<LoginResponse>("/v1/user/verify-with-wechat-app-connect", req, config).then(r => r.data),

    /** Apple登录 */
    loginByApple: (req: LoginByAppleRequest, config?: AxiosRequestConfig) =>
      client.post<LoginResponse>("/v1/user/verify-with-apple", {
        auth: { client_id: req.client_id ?? "art.nieta", code: req.code, redirect_url_used: req.redirect_url_used },
      }, config).then(r => r.data),

    /** Google登录 */
    loginByGoogle: (req: LoginByGoogleRequest, config?: AxiosRequestConfig) =>
      client.post<LoginResponse>("/v1/user/verify-with-google", {
        auth: { client_id: req.client_id, code: req.code },
      }, config).then(r => r.data),

    /** 一键登录验证 */
    verifyOneLogin: (data: Record<string, unknown>, config?: AxiosRequestConfig) =>
      client.post<LoginResponse>("/v1/user/verify-one-login", data, config).then(r => r.data),

    /** 登出 */
    logout: (config?: AxiosRequestConfig) =>
      client.post("/v1/user/logout", {}, config).then(r => r.data),

    /** 刷新Token (使用大写X-Token头) */
    refreshToken: (config?: AxiosRequestConfig) =>
      client.put<LoginResponse>("/v1/user/refresh-token", {}, {
        ...config,
        headers: { ...config?.headers, "Content-Type": "application/json" },
      }).then(r => r.data),

    /** 创建匿名用户 */
    createAnonymousUser: (data?: Record<string, unknown>, config?: AxiosRequestConfig) =>
      client.post("/v2/users/anonymous", data ?? {}, config).then(r => r.data),

    /** 创建广告优化匿名用户 (无需认证) */
    createAnonymousAdUser: (config?: AxiosRequestConfig) =>
      client.post<{ uuid: string; nick_name: string; avatar_url: string | null }>(
        "/v2/users/anonymous-ad", {}, config
      ).then(r => r.data),
  };
};
