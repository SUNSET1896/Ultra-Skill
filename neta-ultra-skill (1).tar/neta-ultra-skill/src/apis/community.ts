/**
 * Neta-Ultra API — 社区/空间/动态模块
 */
import type { AxiosInstance } from "axios";

export const createCommunityApis = (client: AxiosInstance) => {
  return {
    // ====== 空间 (Space) ======
    /** 通过hashtag获取空间 */
    getSpaceByHashtag: (hashtag_name: string) =>
      client.get(`/v1/space/get-by-hashtag?hashtag_name=${hashtag_name}`).then(r => r.data),

    /** 空间话题列表 */
    getTopics: (space_uuid: string) =>
      client.get(`/v1/space/topics?space_uuid=${space_uuid}`).then(r => r.data),

    /** 空间足迹 */
    getFootprint: (space_uuid: string) =>
      client.get(`/v1/space/footprint?space_uuid=${space_uuid}`).then(r => r.data),

    /** 空间游乐场 */
    getPlayground: (space_uuid: string) =>
      client.get(`/v1/space/playground/list?space_uuid=${space_uuid}`).then(r => r.data),

    /** 空间作品集 */
    getCollectionFeed: (params: { space_uuid?: string; page_index?: number }) =>
      client.get(`/v1/space/collection/feed`, { params }).then(r => r.data),

    /** 增加足迹 */
    increaseFootprint: (space_uuid: string) =>
      client.post("/v1/space/increase/footprint", { space_uuid }).then(r => r.data),

    /** 移除空间 */
    removeSpace: (data: Record<string, unknown>) =>
      client.post("/v1/space/remove", data).then(r => r.data),

    // ====== 动态 (Moment) ======
    /** 发布动态 */
    publishMoment: (data: Record<string, unknown>) =>
      client.post("/v1/space/moment/publish", data).then(r => r.data),

    /** 点赞动态 */
    likeMoment: (moment_uuid: string) =>
      client.post("/v1/space/moment/like", { moment_uuid }).then(r => r.data),

    /** 评论动态 */
    commentMoment: (data: Record<string, unknown>) =>
      client.post("/v1/space/moment/comment", data).then(r => r.data),

    /** 删除评论 */
    deleteComment: (uuid: string) =>
      client.delete(`/v1/space/moment/comment/delete?uuid=${uuid}`).then(r => r.data),

    /** 删除动态 */
    deleteMoment: (data: Record<string, unknown>) =>
      client.post("/v1/space/moment/delete", data).then(r => r.data),

    /** 动态详情 */
    getMomentDetail: (moment_uuid: string) =>
      client.get(`/v1/space/moment/detail?moment_uuid=${moment_uuid}`).then(r => r.data),

    /** 禁言 */
    banMoment: (data: Record<string, unknown>) =>
      client.post("/v1/space/admin/moment/ban", data).then(r => r.data),

    // ====== 故事互动 ======
    /** 点赞故事 */
    likeStory: (data: { story_id: string; behavior?: string }) =>
      client.put("/v1/story/story-like", data).then(r => r.data),

    /** 收藏故事 */
    favorStory: (data: { story_id: string; is_cancel?: boolean }) =>
      client.put("/v1/story/story-favor", data).then(r => r.data),

    /** 发布故事 */
    publishStory: (storyId: string, data?: Record<string, unknown>) =>
      client.put(`/v1/story/story-publish?storyId=${storyId}`, data ?? {}).then(r => r.data),

    /** 发布故事V2 */
    publishStoryV2: (data: { storyId: string }) =>
      client.put("/v2/story/story", data).then(r => r.data),
  };
};
