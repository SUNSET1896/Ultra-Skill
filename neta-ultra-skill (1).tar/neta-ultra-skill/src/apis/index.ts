/**
 * Neta-Ultra API — 总入口
 * 
 * 捏Ta (app.nieta.art) v6.11.5 全量API逆向工程
 * 覆盖 30+ 模块, 170+ API端点
 * 
 * 认证方式:
 *   国内版: x-token (小写) 或 X-Token (大写)
 *   海外版: Authorization: Bearer {access_token} (OIDC)
 * 
 * 基础请求头:
 *   x-platform: nieta-app/android (模拟安卓App端)
 *   x-nieta-app-version: 6.11.5
 */
import axios, { AxiosError } from "axios";
import { decodeJwtPayload, isTokenExpired, readToken, TOKEN_REFRESH_ENDPOINT } from "../utils/auth.ts";
import { API_BASE_URL, NETA_TOKEN, PLATFORM, APP_VERSION, APP_BUNDLE_VERSION, APP_BUNDLE_VERSION_CODE } from "../utils/env.ts";
import { ApiResponseError } from "../utils/errors.ts";
import { logger } from "../utils/logger.ts";

// ---- 各模块API工厂 ----
import { createAuthApis } from "./auth.ts";
import { createUserApis } from "./user.ts";
import { createFeedsApis } from "./feeds.ts";
import { createArtifactApis } from "./artifact.ts";
import { createCollectionApis, createVerseApis, createGptApis, createTaskApis, createMakeApis } from "./create.ts";
import { createCommunityApis } from "./community.ts";
import { createHashtagApis } from "./hashtag.ts";
import { createCharacterApis } from "./character.ts";
import { createCommerceApis, createMessageApis, createCheckinApis } from "./commerce.ts";
import {
  createOssApis, createConfigApis, createAgentApis,
  createMemoryApis, createMqttApis, createModerateApis,
  createDeviceApis, createWaitlistApis, createUtilApis,
  createCchatApis, createPromptApis, createStoryApis, createAudioApis,
} from "./system.ts";
import {
  createManuscriptApis, createImageEditApis, createThoumaskApis,
  createPrivilegeApis, createAssignmentApis, createMissionApis,
  createActivityApis, createVerseArtifactApis,
} from "./misc.ts";
import type { PromiseResult } from "./types.ts";

export const createUltraApis = (option?: {
  baseUrl?: string;
  headers?: Record<string, string | string[] | undefined>;
  token?: string;
  logger?: Pick<Console, "error" | "warn" | "info" | "debug">;
}) => {
  const baseUrl = option?.baseUrl ?? API_BASE_URL;
  const log = option?.logger ?? logger;

  const client = axios.create({
    adapter: "fetch",
    baseURL: baseUrl,
    headers: {
      "x-platform": PLATFORM,
      "x-nieta-app-version": APP_VERSION,
      "x-app-bundle-version": APP_BUNDLE_VERSION,
      "x-app-bundle-version-code": APP_BUNDLE_VERSION_CODE,
      ...option?.headers,
    },
    timeout: 30 * 1000,
  });

  // 请求拦截器 — 自动注入token
  client.interceptors.request.use(async (config) => {
    const now = Date.now();
    log.debug("[api] %s %s", config.method, config.url);

    // 1. 优先从配置文件读取 token
    const stored = await readToken();
    let tokenToUse = stored?.token;

    // 2. 检查是否过期，尝试刷新
    if (stored && isTokenExpired(stored) && stored.refreshToken) {
      try {
        log.debug("[api] token expired, refreshing...");
        const refreshRes = await axios.put(`${baseUrl}${TOKEN_REFRESH_ENDPOINT}`, {}, {
          headers: { "X-Token": stored.token, "Content-Type": "application/json" },
          adapter: "fetch",
        });
        // 刷新成功, 使用新token
        tokenToUse = refreshRes.data?.token || tokenToUse;
      } catch (e) {
        log.warn("[api] token refresh failed: %s", e instanceof Error ? e.message : e);
      }
    }

    // 3. Fallback: 使用环境变量
    if (!tokenToUse && NETA_TOKEN) {
      tokenToUse = NETA_TOKEN;
    }

    // 4. 设置认证头
    if (tokenToUse) {
      config.headers.set("x-token", tokenToUse);
    }

    return config;
  });

  // 响应拦截器
  client.interceptors.response.use(
    (response) => {
      log.debug("[api] %s %s %d", response.config.method, response.config.url, response.status);
      return response;
    },
    (error) => {
      if (error instanceof AxiosError) {
        log.debug("[api] error: %s %s %d", error.config?.method, error.config?.url, error.response?.status);
        throw ApiResponseError.fromAxios(error);
      }
      throw error;
    },
  );

  // ---- 组装所有API模块 ----
  const auth = createAuthApis(client);
  const user = createUserApis(client);
  const feeds = createFeedsApis(client);
  const artifact = createArtifactApis(client);
  const collection = createCollectionApis(client);
  const verse = createVerseApis(client);
  const gpt = createGptApis(client);
  const task = createTaskApis(client);
  const make = createMakeApis(client);
  const community = createCommunityApis(client);
  const hashtag = createHashtagApis(client);
  const character = createCharacterApis(client);
  const commerce = createCommerceApis(client);
  const message = createMessageApis(client);
  const checkin = createCheckinApis(client);
  const oss = createOssApis(client);
  const config = createConfigApis(client);
  const agent = createAgentApis(client);
  const memory = createMemoryApis(client);
  const mqtt = createMqttApis(client);
  const moderate = createModerateApis(client);
  const device = createDeviceApis(client);
  const waitlist = createWaitlistApis(client);
  const util = createUtilApis(client);
  const cchat = createCchatApis(client);
  const prompt = createPromptApis(client);
  const story = createStoryApis(client);
  const audio = createAudioApis(client);
  const manuscript = createManuscriptApis(client);
  const imageEdit = createImageEditApis(client);
  const thoumask = createThoumaskApis(client);
  const privilege = createPrivilegeApis(client);
  const assignment = createAssignmentApis(client);
  const mission = createMissionApis(client);
  const activity = createActivityApis(client);
  const verseArtifact = createVerseArtifactApis(client);

  return {
    baseUrl,
    client,
    // 认证
    auth,
    // 用户
    user,
    // Feed
    feeds,
    // 作品
    artifact,
    verseArtifact,
    // 创作生成
    make,
    task,
    gpt,
    // 合集互动
    collection,
    verse,
    // 社区
    community,
    hashtag,
    // 角色
    character,
    // 电商
    commerce,
    // 消息
    message,
    // 签到
    checkin,
    // 系统工具
    oss,
    config,
    agent,
    memory,
    mqtt,
    moderate,
    device,
    waitlist,
    util,
    // C-Chat
    cchat,
    // Prompt/RAG
    prompt,
    // 故事
    story,
    // 音频/BGM
    audio,
    // 手稿
    manuscript,
    // 图片编辑
    imageEdit,
    // 面具
    thoumask,
    // 特权
    privilege,
    // 任务
    assignment,
    // 旅行任务
    mission,
    // 活动
    activity,
  };
};

/** 全量API类型 */
export type UltraApis = PromiseResult<ReturnType<typeof createUltraApis>>;
