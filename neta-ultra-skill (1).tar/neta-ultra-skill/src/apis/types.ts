/**
 * Neta-Ultra API — Types
 * 
 * 捏Ta API 完整类型定义
 * 从 app.nieta.art v6.11.5 JS逆向还原
 */
export type PromiseResult<T> = T extends Promise<infer U> ? U : T;

// ====== 通用类型 ======
export interface GenericPagination<T> {
  page_index: number;
  page_size: number;
  total: number;
  list: T[];
}

export interface ApiErrorDetail {
  type: string;
  loc: string[];
  msg: string;
  input: unknown;
}

export interface ApiErrorResponse {
  detail: string | ApiErrorDetail[];
}

// ====== 用户相关 ======
export interface UserApInfo {
  ap: number;
  temp_ap?: number;
  ap_limit: number;
  unlimited_until: number | null;
  unlimited_time_in_seconds?: number | null;
  true_unlimited_until?: number | null;
  true_unlimited_time_in_seconds?: number | null;
}

export interface UserInfo {
  id: number;
  uuid: string;
  name: string;
  phone_num: string | null;
  status: "VERIFIED" | "UNVERIFIED" | "DELETE" | null;
  review_status: string | null;
  nick_name: string | null;
  avatar_url: string | null;
  subscribe: boolean | null;
  ap_info: UserApInfo | null;
  total_subscribes: number | null;
  total_fans: number | null;
  total_likes: string | null;
  total_same_style: string | null;
  total_collections: string | null;
  total_pictures: number | null;
  total_mission_records: number | null;
  total_travel_characters: number | null;
  subscribe_status: string | null;
  access_token?: string | null;
  complete_newbie_experience: boolean | null;
  oc_published?: boolean;
  is_internal?: boolean;
  is_anonymous?: boolean;
  is_wechat_verified: boolean;
  is_apple_verified: boolean;
  properties: Record<string, unknown> | null;
  extra_data?: Record<string, unknown>;
  badges?: Badge[];
  privileges: UserPrivilege[];
}

export interface Badge {
  uuid: string;
  name: string;
  description: string;
  icon_url: string;
  small_icon_url: string;
  sort_index: number;
  status: "PUBLISHED" | "DEPRECATED";
  ctime: string;
  mtime: string;
  type: "BADGE" | "AVATAR_FRAME" | "VERIFICATION_BADGE" | "THOUMASK_BADGE";
  avatar_frame_url?: string | null;
  avatar_frame_gif_url?: string | null;
  verification_icon_url?: string | null;
  badge_no?: number;
}

export interface UserPrivilege {
  privilege_type: string;
  is_active: boolean;
  valid_until: string;
  valid_until_timestamp: number;
  time_remaining_seconds: number;
  source_type: string;
  config: { enable: boolean } | null;
}

export interface ApDeltaRecord {
  type: string;
  ap_delta: number;
  ctime: string;
  extra_data: {
    display_name: string | null;
    ap_delta_original: number | null;
    discount_percent: number | null;
  } | null;
}

// ====== Feed相关 ======
export interface FeedModule<T = unknown> {
  data_id: string;
  module_id: string;
  template_id: string;
  json_data: T;
  style: Record<string, unknown>;
}

export interface FeedListResponse {
  module_list_header: { module_list: unknown[] };
  module_list: FeedModule[];
  page_data: {
    has_next_page: boolean;
    page_index: number;
    page_size: number;
    biz_trace_id: string;
    extend_data: Record<string, unknown>;
  };
  debug_info?: Record<string, unknown>;
}

// ====== 作品相关 ======
export interface ArtifactItem {
  uuid: string;
  status: string | null;
  url: string | null;
  modality: string | null;
  is_starred: boolean | null;
  user_uuid?: string;
  ctime: string | null;
  mtime: string | null;
  audio_name?: string | null;
  platform?: string;
}

export interface ArtifactDetail {
  uuid: string;
  status: string;
  url: string;
  modality: string;
  audio_name?: string;
}

// ====== 消息相关 ======
export interface MessageSectionCount {
  section_enum: string;
  unread_count: number;
}

export interface MessageItem {
  uuid: string;
  entity_uuid: string;
  entity_type: string;
  comment_uuid: string | null;
  actors: Array<{
    id: number;
    uuid: string;
    nick_name: string;
    avatar_url: string;
  }>;
  section_enum: string;
  ctime: string;
  is_read: boolean;
  content?: string;
}

// ====== Hashtag相关 ======
export interface HashtagInfo {
  name: string;
  hashtag_type?: string;
  heat?: number;
  uuid?: string;
  banner_url?: string;
  description?: string;
  subscribe_count?: number;
  collection_count?: number;
}

export interface LoreEntry {
  uuid?: string;
  title?: string;
  content?: string;
  sort_index?: number;
  hashtag_name?: string;
}

// ====== 电商相关 ======
export interface SpuItem {
  uuid: string;
  name: string;
  config: {
    icon?: string;
    usage?: string;
    icon_bg_color?: string;
    is_first_limit?: boolean;
    purchase_limit?: number;
    success_toast_msg?: string;
    sku_list?: Array<{ id: number; amount: number }>;
  };
  price: string;
}

export interface OrderItem {
  uuid: string;
  spu_uuid: string;
  spu_name: string;
  amount: number;
  price: string;
  status: string;
  ctime: string;
}

// ====== 签到相关 ======
export interface CheckinStatus {
  today_signed: boolean;
  streak_count: number;
  cycle_day: number;
  cycle_signed_history: Array<{ date: string; cycle_day: number }>;
  reward_list: Array<{
    cycle_day: number;
    reward_name: string;
    reward_value: number;
    reward_unit: string | null;
    reward_icon: string;
  }>;
}

// ====== Verse相关 ======
export interface VerseCatalog {
  uuid: string;
  title: string;
  display_type: string;
  sort_index: number;
}

export interface VersePreset {
  uuid: string;
  name: string;
  description?: string;
  template_url?: string;
}

// ====== 活动相关 ======
export interface Activity {
  uuid: string;
  tag_name: string;
  title: string;
  start_time: number;
  end_time: number;
  status: "RUNNING" | "ENDED" | "PENDING";
  popularity: number;
  participants_count: number;
  banner_pic: string;
  small_banner_pic?: string | null;
  creator_name?: string;
  creator_avatar_url?: string;
  weight?: number;
}

// ====== 角色相关 ======
export interface TravelCharacter {
  uuid: string;
  owner_uuid: string;
  status: string;
  travel_distance: number;
  mission_completed_count: number;
  avatar_img: string;
  header_img: string;
  name?: string;
  bio?: string;
}

export interface ParentCatalog {
  uuid: string;
  name: string;
  sort_index: number;
  domain: string;
  img_url: string;
  latest_ctime?: string;
}

// ====== BGM相关 ======
export interface BgmItem {
  uuid: string;
  type: string;
  name: string;
  description: string;
  url: string;
}

// ====== 配置相关 ======
export interface AbExperiment {
  name: string;
  group: string;
  params: Record<string, unknown>;
}

// ====== Agent相关 ======
export interface AgentConversation {
  uuid: string;
  title: string;
  status: string;
  ctime: string;
}

// ====== C-Chat相关 ======
export interface CchatConversation {
  uuid: string;
  character_uuid: string;
  character_name: string;
  last_message?: string;
  ctime: string;
}

// ====== 任务 (Assignment) 相关 ======
export interface Assignment {
  uuid: string;
  name: string;
  description: string;
  assignment_action_type: string;
  reward_type: string;
  reward_value: number;
  status: string;
  progress?: number;
  target?: number;
}

// ====== OSS上传相关 ======
export interface OssStsToken {
  access_key_id: string;
  access_key_secret: string;
  security_token: string;
  expiration?: string;
}

// ====== 等待列表相关 ======
export interface WaitlistStatus {
  is_applied: boolean;
  is_approved: boolean;
  feature_key: string;
}

// ====== MQTT相关 ======
export interface MqttClientConfig {
  client_id?: string;
  endpoint?: string;
  username?: string;
  password?: string;
}

// ====== TC_MEM 记忆相关 ======
export interface TcpMemory {
  uuid: string;
  tcp_uuid: string;
  content: string;
  ctime: string;
}

export interface TcpExperience {
  uuid: string;
  experience_type: string;
  content: string;
  ctime: string;
}

// ====== 手稿相关 ======
export interface ManuscriptItem {
  uuid: string;
  title: string;
  content: string;
  status: string;
  ctime: string;
  mtime: string;
}

// ====== 故事相关 ======
export interface StoryItem {
  storyId: string;
  uuid?: string;
  name?: string;
  coverUrl?: string;
  aspect?: string;
  likeCount?: number;
  status?: string;
}

// ====== 合集互动 ======
export interface CollectionInteractive {
  uuid: string;
  collection_uuid: string;
  interactive_type: string;
  prompt?: string;
  vtokens?: unknown[];
  images?: unknown[];
}
