/**
 * Neta-Ultra API — 作品(Artifact)模块
 * 图片/视频/音频/verse作品管理
 */
import type { AxiosInstance, AxiosRequestConfig } from "axios";
import type { ArtifactItem, ArtifactDetail } from "./types.ts";

export interface ArtifactListParams {
  page_index?: number;
  page_size?: number;
  modality?: string;
  is_starred?: boolean;
}

export const createArtifactApis = (client: AxiosInstance) => {
  return {
    /** 作品列表 */
    list: (params?: ArtifactListParams) =>
      client.get<{ total: number; list: ArtifactItem[] }>("/v1/artifact/list", {
        params: { page_index: params?.page_index ?? 0, page_size: params?.page_size ?? 20, ...params }
      }).then(r => r.data),

    /** 作品详情 (批量,逗号分隔uuid) */
    detail: (uuids: string[]) =>
      client.get<ArtifactDetail[]>("/v1/artifact/artifact-detail", {
        params: { uuids: uuids.join(",") }
      }).then(r => r.data),

    /** 图片作品详情 */
    pictureDetail: (uuid: string) =>
      client.get("/v1/artifact/picture-detail", { params: { uuid } }).then(r => r.data),

    /** 视频作品详情 */
    videoDetail: (uuid: string) =>
      client.get("/v1/artifact/video-detail", { params: { uuid } }).then(r => r.data),

    /** 视频流URL */
    videoStreamUrl: (uuid: string) =>
      client.get("/v1/artifact/video-stream-url", { params: { uuid } }).then(r => r.data),

    /** 视频流 */
    videoStream: (uuid: string) =>
      client.get(`/v1/artifact/video-stream/${uuid}`).then(r => r.data),

    /** 视频任务 */
    videoTask: (uuid: string) =>
      client.get(`/v1/artifact/video_task/${uuid}`).then(r => r.data),

    /** 任务状态查询 */
    task: (task_uuid: string, config?: AxiosRequestConfig) =>
      client.get(`/v1/artifact/task/${task_uuid}`, config).then(r => r.data),

    /** Verse作品列表 */
    verseList: () => client.get("/v1/artifact/verse/list").then(r => r.data),

    /** Verse任务 */
    verseTask: (params?: Record<string, unknown>) =>
      client.get("/v1/artifact/verse/task", { params }).then(r => r.data),

    /** Verse检查点 */
    verseCheckpoint: (params?: Record<string, unknown>) =>
      client.get("/v1/artifact/verse/checkpoint", { params }).then(r => r.data),

    /** 同款权限 */
    tcpPermissionsForSameStyle: (params?: Record<string, unknown>) =>
      client.get("/v1/artifact/tcp-permissions-for-same-style", { params }).then(r => r.data),

    /** 创建图片作品 (上传后) */
    createPicture: (data: { url: string }) =>
      client.post<{ uuid: string }>("/v1/artifact/picture", data).then(r => r.data),

    /** 创建视频作品 (上传后) */
    createVideo: (data: { url: string }) =>
      client.post<{ uuid: string }>("/v1/artifact/video", data).then(r => r.data),

    /** 创建Verse作品 */
    createVerse: (data: Record<string, unknown>) =>
      client.post("/v1/artifact/verse", data).then(r => r.data),

    /** 更新作品 */
    update: (uuid: string, data: Record<string, unknown>) =>
      client.put(`/v1/artifact/${uuid}`, data).then(r => r.data),

    /** 删除作品 */
    delete: (uuid: string) =>
      client.delete("/v1/artifact", { params: { uuid } }).then(r => r.data),

    /** 删除Verse作品 */
    deleteVerse: (uuid: string) =>
      client.delete(`/v1/verse/artifact/${uuid}`).then(r => r.data),
  };
};
