/**
 * Neta-Ultra API — 标签(Hashtag)/世界观模块
 */
import type { AxiosInstance } from "axios";
import type { HashtagInfo, LoreEntry } from "./types.ts";

export const createHashtagApis = (client: AxiosInstance) => {
  return {
    /** 热门社区标签 (无需登录) */
    communityTop: () =>
      client.get<HashtagInfo[]>("/v1/hashtag/community-top").then(r => r.data),

    /** 标签搜索提示 (无需登录) */
    typeahead: (query: string) =>
      client.get(`/v1/hashtag/typeahead/${query}`).then(r => r.data),

    /** 标签搜索V2 (无需登录) */
    typeaheadV2: (query: string) =>
      client.get(`/v1/hashtag/typeahead-v2/${query}`).then(r => r.data),

    /** 标签信息 */
    getInfo: (name: string) =>
      client.get<HashtagInfo>(`/v1/hashtag/hashtag_info/${name}`).then(r => r.data),

    /** 热门合集 */
    hotCollections: (hashtag_name: string) =>
      client.get("/v1/hashtag/hot-collections", { params: { hashtag_name } }).then(r => r.data),

    /** 最新最热合集 */
    latestHottestCollection: () =>
      client.get("/v1/hashtag/latest-hottest-collection").then(r => r.data),

    /** TCP计数 */
    tcpCount: (params?: Record<string, unknown>) =>
      client.get("/v1/hashtag/tcp-count", { params }).then(r => r.data),

    /** Feed标签 */
    feedHashtags: (params?: Record<string, unknown>) =>
      client.get("/v1/hashtag/feed_hashtags", { params }).then(r => r.data),

    /** 订阅计数 */
    subscribeCount: (params?: Record<string, unknown>) =>
      client.get("/v1/hashtag/subscribe-count", { params }).then(r => r.data),

    /** 合集订阅计数 */
    collectionSubscribeCount: (params?: Record<string, unknown>) =>
      client.get("/v1/hashtag/subscribe/collection-count", { params }).then(r => r.data),

    /** Lore计数 */
    loresCount: (params?: Record<string, unknown>) =>
      client.get("/v1/hashtag/lores-count", { params }).then(r => r.data),

    /** 创建Hashtag */
    create: (data: Record<string, unknown>) =>
      client.post("/v1/hashtag/", data).then(r => r.data),

    /** 订阅标签 */
    subscribe: (hashtag_name: string, behavior: string) =>
      client.post("/v1/hashtag/subscribe", { hashtag_name, behavior }).then(r => r.data),

    /** 批量订阅 */
    subscribeBulk: (data: Record<string, unknown>) =>
      client.post("/v1/hashtag/subscribe-bulk", data).then(r => r.data),

    /** 修改标签 */
    modify: (data: Record<string, unknown>) =>
      client.post("/v1/hashtag/modify", data).then(r => r.data),

    /** 取消置顶 */
    removeTop: (name: string) =>
      client.post(`/v1/hashtag/remove-top/${name}`).then(r => r.data),

    // ====== Lore (世界观) ======
    /** 获取Lore */
    getLore: (params?: Record<string, unknown>) =>
      client.post("/v1/hashtag/lore", params ?? {}).then(r => r.data),

    /** 创建Lore */
    createLore: (data: Record<string, unknown>) =>
      client.post("/v1/hashtag/lore", data).then(r => r.data),

    /** 修改Lore */
    modifyLore: (data: Record<string, unknown>) =>
      client.post("/v1/hashtag/lore/modify", data).then(r => r.data),

    /** 删除Lore */
    deleteLore: (data: Record<string, unknown>) =>
      client.post("/v1/hashtag/lore/delete", data).then(r => r.data),

    /** Lore事件 */
    loreEvents: (data: Record<string, unknown>) =>
      client.post("/v1/hashtag/lore/events", data).then(r => r.data),

    /** 批量排序Lore事件 */
    sortLoreEvents: (data: Record<string, unknown>) =>
      client.post("/v1/hashtag/lore/event/sort-index-bulk", data).then(r => r.data),
  };
};
