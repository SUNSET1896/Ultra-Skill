/**
 * Neta-Ultra API — 电商/商业化、消息、签到模块
 */
import type { AxiosInstance } from "axios";
import type { SpuItem, OrderItem, MessageSectionCount, MessageItem, CheckinStatus } from "./types.ts";

export const createCommerceApis = (client: AxiosInstance) => {
  return {
    /** 商品列表 (无需登录) */
    spuList: (params?: Record<string, unknown>) =>
      client.get<{ total: number; list: SpuItem[] }>("/v1/commerce/spu-list", { params }).then(r => r.data),

    /** 商品详情 (无需登录) */
    spuDetail: (uuid: string) =>
      client.get<SpuItem>(`/v1/commerce/spu-detail/${uuid}`).then(r => r.data),

    /** 我的物品 */
    userItems: () => client.get("/v1/commerce/user-items").then(r => r.data),

    /** 使用物品 */
    useItem: (uuid: string, data?: Record<string, unknown>) =>
      client.patch(`/v1/commerce/user-items/${uuid}`, data ?? {}).then(r => r.data),

    /** 订单列表 */
    getOrders: (params?: Record<string, unknown>) =>
      client.get("/v1/commerce/orders", { params }).then(r => r.data),

    /** 订单详情 */
    getOrder: (uuid: string) =>
      client.get(`/v1/commerce/orders/${uuid}`).then(r => r.data),

    /** 创建订单 */
    createOrder: (data: Record<string, unknown>) =>
      client.post("/v1/commerce/orders", data).then(r => r.data),

    /** 创建订单(带ID) */
    createOrderById: (uuid: string, data?: Record<string, unknown>) =>
      client.post(`/v1/commerce/orders/${uuid}`, data ?? {}).then(r => r.data),

    /** AP购买商品 */
    purchaseByAp: (uuid: string) =>
      client.post(`/v1/commerce/purchase_spu_by_ap/${uuid}`).then(r => r.data),

    /** 礼物列表 */
    giftList: (params?: Record<string, unknown>) =>
      client.get("/v1/commerce/gift_list", { params }).then(r => r.data),

    /** 创建邀请码 */
    createCoupon: () =>
      client.post("/v1/coupon/create", {}).then(r => r.data),

    /** 兑换邀请码 */
    redeemCoupon: (coupon_code: string) =>
      client.post("/v1/coupon/redeem", { coupon_code }).then(r => r.data),
  };
};

export const createMessageApis = (client: AxiosInstance) => {
  return {
    /** 消息列表 */
    list: (params?: { page_index?: number; page_size?: number; section_enum?: string }) =>
      client.get<{ total: number; list: MessageItem[] }>("/v1/message/message-list", { params }).then(r => r.data),

    /** 未读消息数 */
    count: () =>
      client.get<{ data: MessageSectionCount[] }>("/v1/message/message-count").then(r => r.data),

    /** 标记消息已读 */
    markRead: (msg_uuid: string) =>
      client.put("/v1/message/message", { msg_uuid }).then(r => r.data),
  };
};

export const createCheckinApis = (client: AxiosInstance) => {
  return {
    /** 签到状态 */
    status: () =>
      client.get<CheckinStatus>("/v1/checkin/status").then(r => r.data),

    /** 手动签到 */
    manual: () =>
      client.post<{ message: string }>("/v1/checkin/manual", {}).then(r => r.data),
  };
};
