#!/usr/bin/env node
import { program } from "@commander-js/extra-typings";
import pkg from "../package.json" with { type: "json" };
import { setupEnvPaths } from "./utils/config.ts";

setupEnvPaths();

program
  .name("neta-ultra")
  .description("捏Ta Neta-Ultra CLI — 全量API客户端 (app.nieta.art)")
  .version(pkg.version);

// 加载所有命令 (各模块自行注册)
// buildCommands 逻辑从 load.ts 导入
// 此处为简化版本, 直接展示可用API路径

program
  .command("list-apis")
  .description("列出所有可用的API端点")
  .action(() => {
    console.log("请参阅 Neta-Ultra-Skill 文档获取完整API列表");
    console.log("Skills目录: ./skills/");
    console.log("API源码:   ./src/apis/");
  });

program.parse(process.argv);
