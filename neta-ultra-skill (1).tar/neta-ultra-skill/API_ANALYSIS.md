# 捏Ta (app.nieta.art) - 完整 API 逆向分析

> 分析日期: 2026-05-10
> 版本: 6.11.5 (build 260508_164908)
> 分析范围: 首页 HTML + 12 个 JS bundle 文件

---

## 一、核心架构

### 1.1 端点 (Base URL)

```
生产环境 (国内): https://api.talesofai.cn
生产环境 (海外): https://api.talesofai.com
开发环境:        https://{env}.api.talesofai.cn   (如 dev.api.talesofai.cn)
```

### 1.2 认证机制

**Token 存储**: localStorage key `NIETA_APP_USER`

**Token 结构** (localStorage中):
```json
{
  "token": "jwt...",
  "expiresAt": 1809508250,
  "refreshToken": "jwt...",
  "refreshExpiresAt": 1809508250,
  "version": 0,
  "isRegister": false
}
```

**JWT Token Payload** (解码后):
```json
{
  "id": 1234567,
  "uuid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
  "phone_num": "138****0000",
  "expires_at": 1800000000,
  "is_register": false,
  "user_agent": "Mozilla/5.0 ...",
  "salt": "xxxxxxxx..."
}
```

**请求头认证**: 使用 **小写** `x-token` 或 **大写** `X-Token` 请求头

### 1.3 Token 刷新

```
PUT /v1/user/refresh-token
Headers: X-Token: {current_token}, Content-Type: application/json
Body: {}
Response: 返回新的 token / refresh_token / expires_in / refresh_expires_in / token_version
```

---

## 二、请求头规范

### 2.1 标准请求头 (通过 `constructHeaders()` 自动注入)

```javascript
// constructHeaders 函数的逻辑：
// 1. 先获取 apiConfig 中配置的基础 headers（x-platform, x-nieta-app-version, x-teen-mode, x-app-bundle-version）
// 2. 如果 accessToken.snapshot 存在，添加 x-token
// 3. 合并动态设置的 customHeaders
```

### 2.2 所有请求头定义

| Header | 值/示例 | 说明 | 必须? |
|--------|---------|------|-------|
| `x-token` | `eyJ...` (JWT) | 用户认证令牌 | **有token时必须** |
| `x-platform` | `nieta-app/android`, `nieta-app/ios`, `nieta-app/android` | 平台标识 | **部分API需要** |
| `x-nieta-app-version` | `6.11.5` | App版本号 | 建议携带 |
| `x-app-bundle-version` | 版本号字符串 | App bundle版本 | 可选 |
| `x-app-bundle-version-code` | 版本code数字 | App版本code | 可选 |
| `x-teen-mode` | `"1"` 或 `"0"` | 青少年模式 | 可选 |
| `Device-id` | 设备UUID | 仅Dify/AI流式接口需要 | 特定接口 |
| `Content-Type` | `application/json` | JSON请求体时必备 | 按需 |

### 2.3 最佳实践请求头模板

```bash
# 有token时
curl -s "$ENDPOINT/path" \
  -H "x-token: $TOKEN" \
  -H "x-platform: nieta-app/android" \
  -H "x-nieta-app-version: 6.11.5" \
  -H "x-teen-mode: 0" \
  -H "Content-Type: application/json"

# 无token时（匿名请求）
curl -s "$ENDPOINT/path" \
  -H "x-platform: nieta-app/android" \
  -H "x-nieta-app-version: 6.11.5"
```

---

## 三、API 端点完整列表

### 图例说明
- 🔓 = 不需要登录态 (匿名可访问)
- 🔒 = 需要登录态 (必须带 x-token)
- 📱 = 需要 x-platform 请求头 (app限定)
- ⚡ = 仅接受 app 请求

---

### 3.1 用户认证相关

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `POST` | `/v1/user/request-verification-code` | 🔓 | 请求验证码 | `phone_num` |
| `POST` | `/v1/user/verify-with-phone-num` | 🔓 | 手机号+验证码登录 | `phone_num`, `code` |
| `POST` | `/v1/user/verify-with-wechat-app-connect` | 🔓 | 微信登录 | `code`, `appid` |
| `POST` | `/v1/user/verify-with-apple` | 🔓 | Apple登录 | `auth.code`, `auth.client_id` |
| `POST` | `/v1/user/verify-with-google` | 🔓 | Google登录 | `auth.code`, `auth.client_id` |
| `POST` | `/v1/user/verify-one-login` | 🔓 | 一键登录 | token相关 |
| `POST` | `/v1/user/logout` | 🔒 | 登出 | - |
| `PUT` | `/v1/user/refresh-token` | 🔒 | 刷新token | - |
| `POST` | `/v2/users/anonymous` | 📱 | 创建匿名用户 | json body |
| `POST` | `/v2/users/anonymous-ad` | 🔓 | 创建广告优化匿名用户 | `{}` 返回 `{uuid, nick_name, avatar_url}` |

### 3.2 用户信息

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/user/` | 🔒 | 获取自己的用户信息 | - |
| `GET` | `/v1/user/?uuid={uuid}` | 🔓 | 获取指定用户信息(公开) | `uuid` |
| `PUT` | `/v1/user/user` | 🔒 | 更新个人信息 | `user_uuid`, `nick_name`, `avatar_url` |
| `GET` | `/v2/user/ap_info` | 🔒 | 获取AP(电量)信息 | - |
| `GET` | `/v2/users/ap-delta-info` | 🔒 | AP变化历史 | `cursor_id`, `page_size` |
| `PUT` | `/v1/user/user-blacklist` | 🔒 | 拉黑/取消拉黑 | `user_uuid`, `is_cancel` |
| `PUT` | `/v1/user/user-subscribe` | 🔒 | 关注/取消关注 | `user_uuid`, `is_cancel` |
| `GET` | `/v1/user/check_im?receiver={uuid}` | 🔒 | 检查IM权限 | `receiver`, `only_check` |

### 3.3 首页Feed流

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/home/feed/mainlist` | 🔓 | 首页热门Feed | 无需参数(可选 theme) |
| `GET` | `/v1/home/feed/interactive` | 🔓 | 互动Feed | 可选分页参数 |
| `GET` | `/v1/home/feed/dynamic` | 🔓 | 动态Feed(关注) | 需要登录态才能看到关注内容 |
| `GET` | `/v1/home/status_queue` | 🔒 | 首页状态队列 | - |
| `GET` | `/v1/home/draft` | 🔒 | 首页草稿 | - |
| `GET` | `/v1/home/collection/{uuid}` | 🔒 | 首页合集详情 | uuid |
| `PUT` | `/v1/home/feature/record` | 🔒 | 首页特征记录 | - |

### 3.4 空间 (Space/Community)

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/space/get-by-hashtag?hashtag_name={name}` | 🔓 | 通过hashtag查空间 | `hashtag_name` |
| `GET` | `/v1/space/topics?space_uuid={uuid}` | 🔓 | 空间话题列表 | `space_uuid` |
| `GET` | `/v1/space/footprint?space_uuid={uuid}` | 🔓 | 空间足迹 | `space_uuid` |
| `GET` | `/v1/space/playground/list?space_uuid={uuid}` | 🔓 | 空间游乐场 | `space_uuid` |
| `GET` | `/v1/space/collection/feed?page_index={n}` | 🔓 | 空间作品集 | `page_index`, `space_uuid` |
| `POST` | `/v1/space/increase/footprint` | 🔒 | 增加足迹 | `space_uuid` |
| `POST` | `/v1/space/remove` | 🔒 | 移除空间 | - |
| `POST` | `/v1/space/moment/publish` | 🔒 | 发布动态 | - |
| `POST` | `/v1/space/moment/like` | 🔒 | 点赞动态 | `moment_uuid` |
| `POST` | `/v1/space/moment/comment` | 🔒 | 评论动态 | - |
| `DELETE` | `/v1/space/moment/comment/delete?uuid={uuid}` | 🔒 | 删除评论 | `uuid` |
| `POST` | `/v1/space/moment/delete` | 🔒 | 删除动态 | - |
| `GET` | `/v1/space/moment/detail?moment_uuid={uuid}` | 🔓 | 动态详情 | `moment_uuid` |
| `POST` | `/v1/space/admin/moment/ban` | 🔒 | 禁言 | - |

### 3.5 作品 (Artifact/Story/Collection) - 核心生成系统

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/artifact/list` | 🔒 | 我的作品列表 | - |
| `GET` | `/v1/artifact/artifact-detail` | 🔒 | 作品详情 | `uuid` |
| `GET` | `/v1/artifact/task/{taskId}` | 🔒 | 任务状态 | taskId |
| `GET` | `/v1/artifact/picture-detail` | 🔒 | 图片作品详情 | `uuid` |
| `GET` | `/v1/artifact/video-detail` | 🔒 | 视频作品详情 | `uuid` |
| `GET` | `/v1/artifact/video-stream-url` | 🔒 | 视频流URL | `uuid` |
| `GET` | `/v1/artifact/video-stream/{uuid}` | 🔒 | 视频流 | uuid |
| `GET` | `/v1/artifact/video_task/{uuid}` | 🔒 | 视频任务 | uuid |
| `GET` | `/v1/artifact/verse/list` | 🔒 | Verse作品列表 | - |
| `GET` | `/v1/artifact/verse/task` | 🔒 | Verse任务 | - |
| `GET` | `/v1/artifact/verse/checkpoint` | 🔒 | Verse检查点 | - |
| `GET` | `/v1/artifact/tcp-permissions-for-same-style` | 🔒 | 同款权限 | - |
| `POST` | `/v1/artifact/picture` | 🔒📱 | 创建图片作品 | `rawPrompt`, 等 |
| `POST` | `/v1/artifact/verse` | 🔒 | 创建Verse作品 | - |
| `POST` | `/v1/artifact/video` | 🔒📱 | 创建视频作品 | - |
| `PUT` | `/v1/artifact/{uuid}` | 🔒 | 更新作品 | uuid |
| `PATCH` | `/v1/artifact/verse` | 🔒 | 更新Verse | - |
| `PUT` | `/v1/artifact/modify-audio-name` | 🔒 | 修改音频名称 | - |
| `DELETE` | `/v1/artifact` | 🔒 | 删除作品 | `uuid` |

### 3.6 V3 生成接口 (图片/视频/音乐)

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `POST` | `/v3/make_image` | 🔒📱 | 生成图片 | `rawPrompt` (必填) |
| `POST` | `/v3/make_video` | 🔒📱 | 生成视频 | - |
| `POST` | `/v3/make_song` | 🔒📱 | 生成音乐 | - |
| `POST` | `/v3/make_face_detailer` | 🔒📱 | 面部细化 | - |
| `POST` | `/v3/video_tool_adjust_speed` | 🔒📱 | 视频变速 | - |
| `POST` | `/v3/ai_director_merge_video_submit_task` | 🔒 | AI导演合并视频 | - |
| `POST` | `/v3/merge_media/v3/submit_task` | 🔒 | 合并媒体 | - |
| `GET` | `/v3/task?taskId={id}` | 🔒 | 任务状态查询 | `taskId` |
| `GET` | `/v3/task-pool` | 🔒 | 任务池状态 | - |
| `GET` | `/v3/video_model_list` | 🔓 | 视频模型列表 | - |
| `GET` | `/v3/story/story-detail` | 🔒 | 故事详情 | `uuids` (逗号分隔) |
| `GET` | `/v3/story/{uuid}` | 🔒 | 故事详情 | uuid |
| `GET` | `/v3/story/feeds` | 🔒 | 故事Feed | - |
| `GET` | `/v3/story/same-style-stories` | 🔒 | 同款故事 | - |
| `GET` | `/v3/story/tcp-permissions-for-same-style` | 🔒 | 同款权限 | - |
| `GET` | `/v3/story/collection-pin-status/{uuid}` | 🔒 | 置顶状态 | uuid |
| `GET` | `/v3/story/travel` | 🔒 | 旅行故事 | - |
| `POST` | `/v3/story/generate-story-title` | 🔒 | 生成故事标题 | - |
| `POST` | `/v3/story/pin` | 🔒 | 置顶故事 | - |
| `PUT` | `/v3/story/story` | 🔒 | 发布/更新故事 | `storyId` |
| `DELETE` | `/v3/story/collection` | 🔒 | 删除合集 | `uuids` |

### 3.7 合集互动 (Collection Interactive)

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/collection-interactive/search` | 🔓 | 搜索互动合集 | - |
| `GET` | `/v1/collection-interactive/char_roll?num={n}` | 🔒 | 角色轮转 | `num` |
| `GET` | `/v1/collection-interactive/collection_uuid={uuid}` | 🔓 | 互动合集详情 | `collection_uuid` |
| `PUT` | `/v1/collection-interactive` | 🔒 | 创建/更新互动 | `interactive_uuid`, 等 |
| `PUT` | `/v1/collection-interactive/text_reply` | 🔒 | 文本回复 | - |
| `PUT` | `/v1/collection-interactives/video-input` | 🔒 | 视频输入 | - |
| `PUT` | `/v1/collection-interactives/vtokens` | 🔒 | VToken操作 | - |

### 3.8 Verse (创作引擎)

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/verse/catalog` | 🔓 | Verse分类目录 | - |
| `GET` | `/v1/verse/catalog/{uuid}` | 🔓 | 分类详情 | uuid |
| `GET` | `/v1/verse/preset/{uuid}` | 🔓 | Verse预设/模板 | uuid |
| `GET` | `/v1/verse/tool` | 🔓 | Verse工具 | - |
| `GET` | `/v1/verse/background_is_running/{uuid}` | 🔒 | 后台运行状态 | uuid |
| `GET` | `/v1/verse/background_should_stop/{uuid}` | 🔒 | 后台应停止 | uuid |
| `POST` | `/v1/verse/background_start` | 🔒 | 启动后台任务 | `artifact_load_uuid` |
| `POST` | `/v1/verse/background_stop` | 🔒 | 停止后台任务 | `artifact_load_uuid` |
| `POST` | `/v1/verse/screenshot` | 🔒 | 截图 | `context` (去掉了__前缀) |
| `POST` | `/v1/verse/modifyhtml` | 🔒 | 修改HTML | - |
| `POST` | `/v1/verse/artifact/{uuid}` | 🔒 | Verse → 作品 | uuid |
| `DELETE` | `/v1/verse/artifact/{uuid}` | 🔒 | 删除Verse作品 | uuid |

### 3.9 故事 (Story V1/V2)

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/story/new-story` | 🔒 | 新故事 | - |
| `GET` | `/v2/story/bulk-list?` | 🔓 | 批量故事列表 | - |
| `GET` | `/v2/story/user-stories` | 🔒 | 用户故事 | - |
| `GET` | `/v2/story/liked-list` | 🔒 | 点赞列表 | - |
| `GET` | `/v2/story/liked-list-cursor` | 🔒 | 点赞列表(游标) | - |
| `GET` | `/v2/story/favor-list-cursor` | 🔒 | 收藏列表(游标) | - |
| `GET` | `/v2/story/newbie/tcp-feed?` | 🔒 | 新手Feed | - |
| `PUT` | `/v1/story/story-like` | 🔒 | 点赞故事 | `story_id`, `behavior` |
| `PUT` | `/v1/story/story-favor` | 🔒 | 收藏故事 | - |
| `PUT` | `/v1/story/story-publish?storyId={id}` | 🔒 | 发布故事 | `storyId` |
| `PUT` | `/v2/story/story` | 🔒 | 发布故事V2 | `storyId` |

### 3.10 角色/OC (Original Character)

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v2/oc/oc/{uuid}` | 🔒 | OC详情 | uuid |
| `GET` | `/v2/oc/list-worlds` | 📱 | 世界列表 | - |
| `GET` | `/v2/oc/tcp-hashtag-candidates` | 🔒 | Hashtag候选 | - |
| `GET` | `/v2/oc/tcp-expand` | 🔒 | 扩展 | - |
| `POST` | `/v2/oc/oc` | 🔒 | 创建OC | - |
| `POST` | `/v2/oc/make_oc_bio` | 🔒 | 生成OC简介 | - |
| `PATCH` | `/v2/oc/oc/{uuid}` | 🔒 | 更新OC | uuid |
| `DELETE` | `/v2/oc/oc/{uuid}` | 🔒 | 删除OC | uuid |

### 3.11 旅行/角色养成 (Travel/Parent)

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/travel/characters/{uuid}` | 🔒 | 角色详情 | uuid |
| `GET` | `/v2/travel/characters` | 🔒📱 | 角色列表 | - |
| `GET` | `/v2/travel/characters/{uuid}` | 🔒📱 | 角色详情 | uuid |
| `POST` | `/v2/travel/characters` | 🔒📱 | 创建角色 | - |
| `POST` | `/v2/travel/characters/{uuid}` | 🔒 | 创建角色(旧) | uuid |
| `GET` | `/v1/travel/mission-records/{uuid}` | 🔒 | 任务记录 | uuid |
| `GET` | `/v2/travel/mission-records/{uuid}` | 🔒 | 任务记录V2 | uuid |
| `PATCH` | `/v1/travel/mission-records/{uuid}` | 🔒 | 更新任务记录 | uuid |
| `PATCH` | `/v2/travel/mission-records/{uuid}` | 🔒 | 更新任务记录V2 | uuid |
| `GET` | `/v2/travel/parent` | 🔒 | 角色养成 | - |
| `GET` | `/v2/travel/parent/{uuid}` | 🔒 | 养成详情 | uuid |
| `POST` | `/v2/travel/parent` | 🔒 | 创建养成 | - |
| `POST` | `/v2/travel/parent/{uuid}` | 🔒 | 创建养成(旧) | uuid |
| `PATCH` | `/v2/travel/parent/{uuid}` | 🔒 | 更新养成 | uuid |
| `DELETE` | `/v2/travel/parent/{uuid}` | 🔒 | 删除养成 | uuid |
| `GET` | `/v2/travel/parent-catalog` | 🔓 | 养成目录 | - |
| `GET` | `/v2/travel/parent-catalog/{uuid}` | 🔓 | 养成目录详情 | uuid |
| `GET` | `/v2/travel/parent-catalog/entries` | 🔓 | 养成目录条目 | - |
| `GET` | `/v2/travel/parent-search` | 🔓 | 养成搜索 | - |
| `GET` | `/v2/travel/parent-search-community` | 🔓 | 社区养成搜索 | - |
| `GET` | `/v2/travel/parent-search-under-hashtag` | 🔓 | Hashtag下搜索 | - |
| `GET` | `/v2/travel/parent/bulk/list?in_editor={bool}` | 🔒 | 批量养成列表 | `in_editor` |
| `PUT` | `/v2/travel/parent/parent-favor` | 🔒 | 收藏养成 | - |
| `GET` | `/v2/travel/parent/parent-favor/groups` | 🔒 | 收藏分组 | - |
| `GET` | `/v2/travel/parent/parent-favor/list` | 🔒 | 收藏列表 | - |
| `GET` | `/v2/travel/campaign-search` | 🔓 | 活动搜索 | - |
| `GET` | `/v2/travel/campaign/bulk/list?` | 🔓 | 活动批量列表 | - |
| `GET` | `/v2/travel/campaign/catalog/{uuid}` | 🔓 | 活动目录 | uuid |
| `GET` | `/v2/travel/campaign/catalogs` | 🔓 | 活动目录列表 | - |
| `GET` | `/v3/travel/campaign/{uuid}` | 🔒 | 活动详情V3 | uuid |
| `GET` | `/v3/travel/campaign/recommend` | 🔒 | 活动推荐 | - |
| `GET` | `/v3/travel/campaigns` | 🔒 | 活动列表 | - |
| `DELETE` | `/v3/travel/campaign/{uuid}` | 🔒 | 删除活动 | uuid |
| `GET` | `/v3/travel/mission-record/{uuid}` | 🔒 | 任务记录V3 | uuid |

### 3.12 社交/消息

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/message/message-list` | 🔒 | 消息列表 | 可选分页 |
| `GET` | `/v1/message/message-count` | 🔒 | 未读消息数 | - |
| `PUT` | `/v1/message/message` | 🔒 | 标记消息已读 | `msg_uuid` |

### 3.13 Hashtag/标签

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/hashtag/community-top` | 🔓 | 热门社区标签 | - |
| `GET` | `/v1/hashtag/typeahead/{query}` | 🔓 | 标签搜索提示 | query |
| `GET` | `/v1/hashtag/typeahead-v2/{query}` | 🔓 | 标签搜索V2 | query |
| `GET` | `/v1/hashtag/hashtag_info/{name}` | 🔓 | 标签信息 | name |
| `GET` | `/v1/hashtag/hot-collections` | 🔓 | 热门合集 | `hashtag_name` |
| `GET` | `/v1/hashtag/latest-hottest-collection` | 🔓 | 最新最热合集 | - |
| `GET` | `/v1/hashtag/tcp-count` | 🔓 | TCP计数 | - |
| `GET` | `/v1/hashtag/feed_hashtags` | 🔓 | Feed标签 | - |
| `GET` | `/v1/hashtag/subscribe-count` | 🔓 | 订阅计数 | - |
| `GET` | `/v1/hashtag/subscribe/collection-count` | 🔓 | 合集订阅计数 | - |
| `GET` | `/v1/hashtag/lores-count` | 🔓 | Lore计数 | - |
| `POST` | `/v1/hashtag/` | 🔒 | 创建hashtag | - |
| `POST` | `/v1/hashtag/subscribe` | 🔒 | 订阅标签 | `hashtag_name`, `behavior` |
| `POST` | `/v1/hashtag/subscribe-bulk` | 🔒 | 批量订阅 | - |
| `POST` | `/v1/hashtag/modify` | 🔒 | 修改标签 | - |
| `POST` | `/v1/hashtag/remove-top/{name}` | 🔒 | 取消置顶 | name |
| `POST` | `/v1/hashtag/lore` | 🔒 | 创建Lore | - |
| `POST` | `/v1/hashtag/lore/modify` | 🔒 | 修改Lore | - |
| `POST` | `/v1/hashtag/lore/delete` | 🔒 | 删除Lore | - |
| `POST` | `/v1/hashtag/lore/events` | 🔒 | Lore事件 | - |
| `POST` | `/v1/hashtag/lore/event/sort-index-bulk` | 🔒 | 批量排序 | - |

### 3.14 电商/商业化

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/commerce/spu-list` | 🔓 | 商品列表 | - |
| `GET` | `/v1/commerce/spu-detail/{uuid}` | 🔓 | 商品详情 | uuid |
| `GET` | `/v1/commerce/user-items` | 🔒 | 我的物品 | - |
| `GET` | `/v1/commerce/orders` | 🔒 | 我的订单 | - |
| `GET` | `/v1/commerce/orders/{uuid}` | 🔒 | 订单详情 | uuid |
| `POST` | `/v1/commerce/orders` | 🔒 | 创建订单 | - |
| `POST` | `/v1/commerce/orders/{uuid}` | 🔒 | 创建订单(带ID) | uuid |
| `POST` | `/v1/commerce/purchase_spu_by_ap/{uuid}` | 🔒 | AP购买商品 | uuid |
| `PATCH` | `/v1/commerce/user-items/{uuid}` | 🔒 | 使用物品 | uuid |
| `GET` | `/v1/commerce/gift_list` | 🔒 | 礼物列表 | - |
| `POST` | `/v1/coupon/create` | 🔒 | 创建邀请码 | - |
| `POST` | `/v1/coupon/redeem` | 🔒 | 兑换邀请码 | `coupon_code` |

### 3.15 每日签到

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/checkin/status` | 🔒 | 签到状态 | - |
| `POST` | `/v1/checkin/manual` | 🔒 | 手动签到 | `{}` |

### 3.16 Agent (聊天机器人)

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/agent/limit-exceeded` | 🔒 | 额度检查 | - |
| `POST` | `/v1/agent/` | 🔒 | 创建Agent对话 | - |
| `DELETE` | `/v1/agent/{id}` | 🔒 | 删除Agent | id |

### 3.17 C-Chat (角色聊天)

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/cchat/conversations/{uuid}` | 🔒 | 对话列表 | uuid |
| `GET` | `/v1/cchat/conversation/{uuid}` | 🔒 | 对话详情 | uuid |
| `POST` | `/v1/cchat/conversation/{uuid}` | 🔒 | 创建对话 | uuid |
| `POST` | `/v1/cchat/conversation/casual` | 🔒 | 闲聊对话 | - |
| `POST` | `/v1/cchat/conversation/primary` | 🔒 | 主要对话 | - |
| `POST` | `/v1/cchat/conversation/travel` | 🔒 | 旅行对话 | - |

### 3.18 记忆系统 (TC_MEM)

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/tc_mem/memory` | 🔒 | 记忆查询 | `tcp_uuid` |
| `GET` | `/v1/tc_mem/reflection` | 🔒 | 反思 | - |
| `GET` | `/v1/tc_mem/experiences` | 🔒 | 经验 | - |
| `GET` | `/v1/tc_mem/cchat-messages` | 🔒 | 聊天消息 | - |
| `POST` | `/v1/tc_mem/cchat-messages` | 🔒 | 创建聊天消息 | - |
| `POST` | `/v1/tc_mem/experiences/abstracts/sample` | 🔒 | 经验抽样 | - |
| `DELETE` | `/v1/tc_mem/context-messages` | 🔒 | 删除上下文消息 | `context_uuid` |

### 3.19 手稿系统 (Manuscript)

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/manuscript/list` | 🔒 | 手稿列表 | - |
| `GET` | `/v1/manuscript/{uuid}` | 🔒 | 手稿详情 | uuid |
| `POST` | `/v1/manuscript` | 🔒 | 创建手稿 | - |
| `PUT` | `/v1/manuscript/{uuid}` | 🔒 | 更新手稿 | uuid |
| `PATCH` | `/v1/manuscript/{uuid}` | 🔒 | 部分更新手稿 | uuid |
| `DELETE` | `/v1/manuscript/{uuid}` | 🔒 | 删除手稿 | uuid |

### 3.20 徽章系统

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/badge/me/badges` | 🔒 | 我的徽章 | - |
| `PUT` | `/v1/badge/me/active-avatar-frame` | 🔒 | 设置头像框 | `badge_uuid` |

### 3.21 活动/任务

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/activities` | 🔓 | 活动列表 | - |
| `GET` | `/v1/activities/{uuid}` | 🔓 | 活动详情 | uuid |
| `GET` | `/v1/assignment/assignment-list` | 🔒 | 任务列表 | - |
| `GET` | `/v1/assignment/user-assignment` | 🔒 | 用户任务 | - |
| `PUT` | `/v1/assignment/complete-assignment-action` | 🔒 | 完成任务 | - |

### 3.22 配置/实验

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/configs/config` | 🔓 | 单条配置 | `namespace`, `name` |
| `GET` | `/v1/configs/config-list` | 🔓 | 配置列表 | `namespace` |
| `POST` | `/v1/ab-experiment/get-or-join/all-running` | 🔓 | 加入AB实验 | - |
| `GET` | `/v1/app-release/latest-release` | 🔓 | 最新版本 | `channel` |

### 3.23 文件上传/OSS

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/oss/anonymous-upload-token` | 🔓 | 匿名上传STS Token | `suffix` (如 png), `t` |
| `GET` | `/v1/oss/sts-upload-token` | 🔒 | 登录上传STS Token | `suffix`, `t` |

### 3.24 工具

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `POST` | `/v1/util/short-url` | 🔓 | 生成短链接 | `original_url` |
| `GET` | `/v1/util/original-url` | 🔓 | 解析短链接 | `short_url` |
| `GET` | `/v1/util/get-readable` | 🔓 | 可读信息 | - |

### 3.25 音频/BGM

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/audio/bgm/list` | 🔓 | BGM列表 | 可选分页 |
| `GET` | `/v1/audio/bgm` | 🔓 | BGM详情 | `uuid` |

### 3.26 审核/申诉

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `POST` | `/v1/moderate/appeal` | 🔒 | 申诉 | `user_uuid`, `target_uuid`, `target_type`, `content` |

### 3.27 特权

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/privilege/config/water_mark_remove` | 🔒 | 去水印状态 | - |
| `POST` | `/v1/privilege/config/water_mark_remove?enable={0\|1}` | 🔒 | 设置去水印 | `enable` |

### 3.28 设备注册

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `POST` | `/v1/device/register` | 🔒 | 注册设备(推送) | `token`, `platform` |
| `POST` | `/v1/device/deregister` | 🔒 | 注销设备 | - |

### 3.29 Waitlist

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/waitlist/status` | 🔓 | Waitlist状态 | `feature_key` (限 `html_patch`) |
| `POST` | `/v1/waitlist/apply` | 🔒 | 申请Waitlist | `feature_key`, `reason` |

### 3.30 MQTT

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `POST` | `/v1/mqtt/client` | 🔒 | 获取MQTT连接凭证 | `client_id` |

### 3.31 RAG/Prompt

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/prompt/full-prompt-tags` | 🔒 | 提示词标签 | - |
| `GET` | `/v1/rag/cached-inspiration` | 🔒 | 缓存灵感 | - |
| `POST` | `/v1/rag/rag-recommend-stories` | 🔒 | RAG推荐 | - |

### 3.32 图片编辑

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `POST` | `/v1/image_edit_v1/task` | 🔒 | 图片编辑任务 | - |

### 3.33 Dify AI 文本生成 (流式)

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `POST` | `/v3/gpt/dify/text-complete` | 🔒📱 | Dify流式文本补全 | `query`, `response_mode:"streaming"`, `preset_key`, `inputs` |

### 3.34 GPT消息

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v3/gpt/message/{uuid}` | 🔒 | GPT消息 | uuid |

### 3.35 面具

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/thoumask/masks?` | 🔒 | 面具列表 | - |

### 3.36 App加载

| 方法 | 路径 | 权限 | 说明 | 关键参数 |
|------|------|------|------|----------|
| `GET` | `/v1/app/loads` | 🔒 | App加载资源 | - |

---

## 四、特殊 API 说明

### 4.1 匿名用户创建 (广告优化)
```bash
POST /v2/users/anonymous-ad
Header: Content-Type: application/json
Body: {}
Response: {"uuid": "...", "nick_name": "风一样的克洛伊", "avatar_url": null, ...}
```
此接口无需任何认证即可调用。

### 4.2 OSS上传
```bash
# 匿名上传 - 无需登录
GET /v1/oss/anonymous-upload-token?suffix=png&t={timestamp}

# 登录上传 - 需要x-token
GET /v1/oss/sts-upload-token?suffix=png&t={timestamp}
```
返回包含 `access_key_id`, `access_key_secret`, `security_token` 的STS临时凭证。

### 4.3 Dify流式文本生成
```bash
POST /v3/gpt/dify/text-complete
Headers:
  x-token: {token}
  x-platform: nieta-app/android
  Content-Type: application/json
  Device-id: {deviceUUID}
Body: {
  "query": "",
  "response_mode": "streaming",
  "preset_key": "奇遇总结",  // 或 "AI帮写帖子"
  "inputs": {
    "info": "...",
    "name": "...",
    "plot": "assistant:..."
  }
}
```

### 4.4 "此接口只接受app请求"
以下接口返回 `{"detail":"此接口只接受app请求"}` 需要携带 `x-platform` 头:
- `/v2/travel/characters` (GET/POST)
- `/v3/make_image`, `/v3/make_video`, `/v3/make_song`, `/v3/make_face_detailer`
- `/v2/oc/list-worlds`
- `/v1/artifact/picture` (POST)
- `/v1/artifact/video` (POST)

### 4.5 Token刷新机制
```bash
PUT /v1/user/refresh-token
Headers:
  X-Token: {current_token}    # 注意大写X-Token
  Content-Type: application/json
Body: {}
```
返回新token后需要更新localStorage。

---

## 五、认证判断逻辑总结

### 不需要登录态 (🔓) 的接口类别:
1. **Feed浏览**: 首页热门、互动Feed
2. **公开内容**: 合集详情、故事列表、Verse目录、活动浏览
3. **用户注册/登录**: 所有verify接口
4. **标签浏览**: community-top, typeahead, hashtag_info
5. **OSS匿名上传**: anonymous-upload-token
6. **配置**: configs, app-release, activities
7. **BGM列表**: audio/bgm/list
8. **匿名用户**: anonymous-ad

### 需要登录态 (🔒) 的接口类别:
1. **所有写操作**: 创建/修改/删除 (除了登录注册)
2. **用户私有数据**: user/, artifact/list, message/*, checkin/*
3. **生成类**: make_image, make_video 等
4. **互动操作**: like, subscribe, comment, favor
5. **订单/支付**: commerce/orders, coupon/*

### 需要x-platform头的接口 (📱):
部分接口会检查 `x-platform` 头，主要是v3生成接口和travel相关接口。

---

## 六、请求头生成函数 (JS逆向还原)

```javascript
// constructHeaders() - 从 talesofai-modules-core 逆向还原
async function constructHeaders() {
  // 1. 获取基础headers (来自 apiConfig)
  const baseHeaders = {
    "x-platform": "nieta-app/android",    // 模拟安卓App端 (web: nieta-app/web, ios: nieta-app/ios)
    "x-nieta-app-version": "6.11.5",
    "x-teen-mode": "0"                // 青少年模式: "1"
  };
  
  // 2. 如果存在token，添加到headers
  const token = accessToken.snapshot; // 从 localStorage NIETA_APP_USER 读取
  if (token) {
    baseHeaders["x-token"] = token;
  }
  
  // 3. 合并动态customHeaders
  return { ...baseHeaders, ...customHeaders };
}
```

---

## 七、Token信息示例

以下为示例用户信息 (实际值取决于所用Token):
- **用户名**: 示例用户 (UserExample)
- **UUID**: `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`
- **用户ID**: 1234567
- **VIP**: 等级取决于订阅
- **AP(电量)**: 取决于账户余额
- **状态**: VERIFIED / UNVERIFIED

---

## 八、常见API调用示例

### 获取首页Feed
```bash
curl -s "https://api.talesofai.cn/v1/home/feed/mainlist" \
  -H "x-platform: nieta-app/android"
```

### 获取用户信息
```bash
curl -s "https://api.talesofai.cn/v1/user/" \
  -H "x-token: $neta_token"
```

### 签到
```bash
curl -s -X POST "https://api.talesofai.cn/v1/checkin/manual" \
  -H "x-token: $neta_token" \
  -H "Content-Type: application/json" \
  -d '{}'
```

### 刷新Token
```bash
curl -s -X PUT "https://api.talesofai.cn/v1/user/refresh-token" \
  -H "X-Token: $neta_token" \
  -H "Content-Type: application/json" \
  -d '{}'
```

### 获取作品列表
```bash
curl -s "https://api.talesofai.cn/v1/artifact/list" \
  -H "x-token: $neta_token"
```
